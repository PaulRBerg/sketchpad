<?php

// this 'include' is for some core functions specific to skycity. not important for php.
include '../../../../SkycityFunctions.php';
$conn = globalAccess();

$PlaceID = $_POST['PlaceID'];

// These lines are for MySQL retrieval of data. This is a multilateral code, it has both PHP and MySQL.
$SQL = "SELECT Name, City, Address, Contact, Description, Email, Site, Maps FROM Places WHERE ID = '" . $PlaceID . "' LIMIT 1";
$results = $conn -> query($SQL);

$SQL = "SELECT MenuOnline, Ordering, PaymentMethods FROM PlacesMetadata WHERE PlaceID = '" . $PlaceID . "' LIMIT 1";
$metadata = $conn -> query($SQL);

// If the variable "$results" in which we stored the data retrieved earlier has anything in it, get it and print it out.
if($results -> num_rows > 0){
    // fetch_assoc() transforms SQL type data into php readable values.
    while($row = $results -> fetch_assoc()){
        $metaRow = $metadata -> fetch_assoc();
        $row['MenuOnline'] = $metaRow['MenuOnline'];
        $row['Ordering'] = $metaRow['Ordering'];
        $row['PaymentMethods'] = $metaRow['PaymentMethods'];
        $output[] = $row;
    }
    print(json_encode($output));
}
// if the variable is empty, print that there was no place found with the specific ID given.
else{
    echo 'NO_PLACE_FOUND';
}


$conn -> close();
?>