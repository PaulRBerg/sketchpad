<?php

// this 'include' is for some core functions specific to skycity. not important for php.
include '../../../../SkycityFunctions.php';
$conn = globalAccess();

// Initial variables -> $_POST is for getting the value from the mobile app. (POST is a type of request, google it for more info)
$PlaceID = $_POST['PlaceID'];
$PostID = $_POST['PostID'];
$UserID = $_POST['UserID'];
$TimeSent = $_POST['TimeSent'];

// If some shit occurred, stop the execution of the code.
if(empty($PlaceID) || empty($PostID) || empty($UserID) || empty($TimeSent)){
    exit("CONNECTION_ERROR");
}

// Get the data link
$link = "../../Data/Users/Posts/PostComments/";
$fileLink = $link . $PlaceID . "-" . $PostID;
$readFile = fopen($fileLink, "r") or exit("CONNECTION_ERROR");

// fgets() gets a line from a file and the following lines edit the first number of the file
$newNumber = fgets($readFile);
$newNumber = substr($newNumber, 0, strlen($newNumber) - 1);
$newNumber = $newNumber - 1;
$newNumber = $newNumber . PHP_EOL;
$allFileContent = $newNumber;


// '.' operator is for concatation. E.G. : $var = 'prea' . 'teava. $var will become 'preateava'.
$firstComparator = $UserID . $TimeSent;
$iterated = false;

// some comment removal logic (not important for php)
while(!feof($readFile)) {
    $readLine = fgets($readFile);
    // obsiously, strlen returns the string's length
    $strlen = strlen($readLine);

    $id = "";
    $timeSent = "";
    $comment = "";
    $current = 0;
    for($i = 0; $i < $strlen; ++$i){
        $char = substr($readLine, $i, 1);
        if($i == 0 && !is_numeric($char)){
            continue;
        }
        if($char == " " && $current < 2) {
            $current ++;
        }
        else{
            if($current == 0){
                $id .= $char;
            }
            else if($current == 1){
                $timeSent .= $char;
            }
            else if($current == 2){
                $comment .= $char;
            }
        }
    }

    $secondComparator = $id . $timeSent;
    if($firstComparator == $secondComparator){
        continue;
    }

    $allFileContent .= 'N' . $id . ' ' . $timeSent . ' ' . $comment;
    $iterated = true;
}
// After everything finished, rewrite the new content to the file and close the file (just like in c++).
$allFileContent = substr($allFileContent, 0, strlen($allFileContent) - 1);
fclose($readFile);

/*file_put_contents($fileLink, "") or exit("CONNECTION_ERROR");*/
$writeFile = fopen($fileLink, "w");
fwrite($writeFile, "");
fwrite($writeFile, $allFileContent);
fclose($writeFile);

// echo is like fprintf or cout
echo 'UPDATED_SUCCESSFULLY';

// close the connection to the database after you have made all the changes you wanted to
$conn -> close();
?>