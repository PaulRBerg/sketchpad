<?php

include '../../../../../../libs/skycity-classes.php';
$conn = globalAccess($localsys);

$senderID = $_POST['senderID'];
$placeID = $_POST['placeID'];
$destinationID = $_POST['destinationID'];

$SQL = "SELECT userID FROM place" . $placeID ."_connection WHERE userID = '" . $destinationID . "' AND visible = 1 LIMIT 1";
$results = $conn -> query($SQL);

if($results -> num_rows > 0){
	$message = mysql_escape_mimic(secureString($_POST['message']));
	$type = $_POST['type'];
	$timeSent = $_POST['timeSent'];
	
	$SQL = "INSERT INTO Place_" . $placeID . "_Messages(senderID,destinationID,timeSent,type,message) VALUES('" . $senderID . "', '" . $destinationID . "','" . $timeSent . "', '" . $type . "', '" . $message . "') ";
	$conn -> query($SQL);
	
	/*
	$SQL = "SELECT DeviceToken FROM Users WHERE ID = '" . $DestinationID . "' LIMIT 1";
	$results = $conn -> query($SQL);
	$results = $results -> fetch_assoc();
	$deviceToken = $results['DeviceToken'];
	
	if(!empty($deviceToken)){
		$obj = new APNS_Push();
		writeToLog(var_dump($obj));
		if($obj -> connectToAPNS()){
			$messageID = $SenderID . '-' . $TimeSent;
			$payload = '{"aps":{"alert":"You have new messages","sound":"default","badge":1}}';
			if($obj -> sendNotification($messageID, $deviceToken, $payload)){
				$obj -> disconnectFromAPNS();
				$obj = NULL;
			}
			else{
				writeToLog('Failed to connect');	
			}
		}
	}
	*/
	
	echo 'response-ok';
}
else{
	echo 'response-negative';
}

$conn -> close();
?>