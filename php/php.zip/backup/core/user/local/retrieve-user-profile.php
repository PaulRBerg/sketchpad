<?php

include '../../../../../SkycityFunctions.php';
$conn = globalAccess();

$sql = "SELECT Name, City, Birthday, Phone, Facebook,Email,Description, Gender FROM Users WHERE ID = '" . $_POST['UserID'] . "' LIMIT 1";
$results = $conn -> query($sql);

if($results -> num_rows > 0){
	while($row = $results -> fetch_assoc()){
	
		$row['Name'] = unsecureString($row['Name']);
		$row['City'] =  unsecureString($row['City']);
		$row['Phone'] =  unsecureString($row['Phone']);
		$row['Birthday'] = unsecureString($row['Birthday']);
		$row['Facebook'] = unsecureString($row['Facebook']);
		$row['Description'] = unsecureString($row['Description']);
$row['Email'] = unsecureString($row['Email']);
		$output[] = $row;
	}
	print(json_encode($output));
}
else{
	echo 'NO_USER_FOUND';
}

$conn -> close();
?>