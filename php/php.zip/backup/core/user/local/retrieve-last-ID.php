<?php

include '../../../../../SkycityFunctions.php';
$conn = globalAccess();

$PlaceID = $_POST['PlaceID'];
$From = $_POST['From'];

if($From == 1){
	$SQL = "SELECT ID FROM Place_" . $PlaceID . "_Orders ORDER BY ID DESC LIMIT 1";
	$results = $conn -> query($SQL);
	
	if($results -> num_rows > 0){
		$results = $results -> fetch_assoc();
		echo $results['ID'];
	}
	else{
		echo 'NO_ID_FOUND';
	}
}
else{
	echo 'NO_ID_FOUND';
}

$conn -> close();
?>