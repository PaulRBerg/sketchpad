<?php

include '../../../../../SkycityFunctions.php';
$conn = globalAccess();

$SenderID = $_POST['SenderID'];
$DestinationID = $_POST['Destination']; /// TO CHANGE SOME DAY !!!!
$PlaceID = $_POST['PlaceID'];

$sql = "SELECT ID FROM Place_" . $PlaceID . "_Notifications WHERE SenderID = " . $SenderID . " AND DestinationID = " . $DestinationID . " AND Type = 3 AND TIMESTAMPDIFF(MINUTE,TimeSent,NOW()) < 60";
$results = $conn -> query($sql);

if($results->num_rows>0){
	echo "WAIT";
}
else{
	$sql = "INSERT INTO Place_" . $PlaceID . "_Notifications (SenderID, DestinationID, Type, Content, Seen) VALUES (" . $SenderID . ", " . $DestinationID . ", 3, 'POKE', 0)";
	$conn -> query($sql);
	echo "OK";
}

$conn -> close();

?>