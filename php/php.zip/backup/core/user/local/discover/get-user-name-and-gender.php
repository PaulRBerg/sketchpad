<?php

include '../../../../../../SkycityFunctions.php';
$conn = globalAccess();

$SQL = "Select Name, Gender FROM Users WHERE ID = " . $_POST['UserID'] . " LIMIT 1";
$results = $conn -> query($SQL);

if($results -> num_rows > 0){
	$row = $results -> fetch_assoc();
	$row['Name'] = unsecureString($row['Name']);
	if(empty($row['Gender'])){
    			$row['Gender'] = "";
    	}
    		
	if(empty($_POST['Granted'])){
    		echo $row['Name'] . "~" . $row['Gender'];
    	}
    	else{
    		$output[] = $row;
    		print(json_encode($output));
    	}
}
else{
	echo 'NO_USER_FOUND';
}

$conn -> close();
?>