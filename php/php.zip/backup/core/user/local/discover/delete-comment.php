<?php

include '../../../../../../libs/skycity-functions.php';
$conn = globalAccess();

$PlaceID = $_POST['PlaceID'];
$PostID = $_POST['PostID'];
$UserID = $_POST['UserID'];
$TimeSent = $_POST['TimeSent'];

if(empty($PlaceID) || empty($PostID) || empty($UserID) || empty($TimeSent)){
    exit("CONNECTION_ERROR");
}

$link = "../../../../Data/Users/Posts/PostComments/";
$fileLink = $link . $PlaceID . "-" . $PostID;
$readFile = fopen($fileLink, "r") or exit("CONNECTION_ERROR");

$newNumber = fgets($readFile);
$newNumber = substr($newNumber, 0, strlen($newNumber) - 1);
$newNumber = $newNumber - 1;
$newNumber = $newNumber . PHP_EOL;
$allFileContent = $newNumber;


$firstComparator = $UserID . $TimeSent;
$iterated = false;
while(!feof($readFile)) {
	$readLine = fgets($readFile);
	$strlen = strlen($readLine);
	
	$id = "";
	$timeSent = "";
	$comment = "";
	$current = 0;
	for($i = 0; $i < $strlen; ++$i){
		$char = substr($readLine, $i, 1);
		if($i == 0 && !is_numeric($char)){
			continue;
		}
		if($char == " " && $current < 2) { 
				$current ++;
		}
		else{
			if($current == 0){
				$id .= $char;
			}
			else if($current == 1){
				$timeSent .= $char;
			}
			else if($current == 2){
				$comment .= $char;
			}
		}
	}
	
	$secondComparator = $id . $timeSent;
	if($firstComparator == $secondComparator){
		continue;
	}
	
	$allFileContent .= 'N' . $id . ' ' . $timeSent . ' ' . $comment;
	$iterated = true;
}
$allFileContent = substr($allFileContent, 0, strlen($allFileContent) - 1);
fclose($readFile);

/*file_put_contents($fileLink, "") or exit("CONNECTION_ERROR");*/
$writeFile = fopen($fileLink, "w");
fwrite($writeFile, "");
fwrite($writeFile, $allFileContent);
fclose($writeFile);

echo 'UPDATED_SUCCESSFULLY';
$conn -> close();
?>