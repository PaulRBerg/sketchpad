<?php

/********************

------- Type --------

1 is for Discover report, like an offesive picture or some NSFW.
2 is for Waiter report, like a false order.
3 is for Person report.

/*******************/
include '../../../../../../SkycityFunctions.php';
$conn = globalAccess();

$Type = $_POST['Type'];


if($Type == 1){
	$UserID = $_POST['UserID'];
	$PlaceID = $_POST['PlaceID'];
	$PostID = $_POST['PostID'];
	$DestinationID = $_POST['DestinationID'];
	$Content = $_POST['Content']; $Content = secureString($Content);
	
	$SQL = "INSERT INTO Reports(UserID, Content) VALUES(" . $UserID . ", 'Post Report in PlaceID : " . $PlaceID . " to PostID : " . $PostID . " of UserID : " . $DestinationID . " reason : " . $Content . "') ";
	$conn -> query($SQL);
	
	echo 'UPDATED_SUCCESSFULLY';
}

else if($Type == 2){
	$UserID = $_POST['UserID'];
	$PlaceID = $_POST['PlaceID'];
	$OrderID = $_POST['OrderID'];
	$DestinationID = $_POST['DestinationID'];
	$Content = $_POST['Content']; $Content = secureString($Content);
	
	$SQL = "INSERT INTO Reports(UserID, Content) VALUES(" . $UserID . ", 'Order Report in PlaceID : " . $PlaceID . " to OrderID : " . $OrderID . " of UserID : " . $DestinationID . " reason : " . $Content . "') ";
	$conn -> query($SQL);
	
	echo 'UPDATED_SUCCESSFULLY';
}

else if($Type == 3){
	$UserID = $_POST['UserID'];
	$DestinationID = $_POST['DestinationID'];
	$Content = $_POST['Content']; $Content = secureString($Content);
	
	$SQL = "INSERT INTO Reports(UserID, Content) VALUES(" . $UserID . ", 'Person Report to UserID : " . $DestinationID . " reason : " . $Content . "') ";
	$conn -> query($SQL);
	
	echo 'UPDATED_SUCCESSFULLY';
}


$conn -> close();
?>