<?php

include '../../../../../../SkycityFunctions.php';
$conn = globalAccess();

$PlaceID = $_POST['PlaceID'];
$PostID = $_POST['PostID'];
$Content = secureString($_POST['Content']);

$SQL = "UPDATE Place_" . $PlaceID . "_Posts SET Content = '" . $Content . "' WHERE ID = '" . $PostID . "' ";

if($conn -> query($SQL)){
	echo 'UPDATED_SUCCESSFULLY';
}
else{
	echo 'CONNECTION_ERROR';
}

$conn -> close();
?>