<?php
/**
 * Created by PhpStorm.
 * User: razvanpaul
 * Date: 31/12/15
 * Time: 14:58
 */

include '../../../../../../libs/skycity-functions.php';
$conn = globalAccess($localsys);

$userID = $_POST['userID'];
$placeID = $_POST['placeID'];
$placeName = "";
$limit = $_POST['limit'];
$offset = $_POST['offset'];

$SQL = "SELECT postID, senderID, content, attachment, timePosted
        FROM place_" . $placeID . "_post
        ORDER BY timePosted DESC
        LIMIT " . $limit . "
        OFFSET " . $offset . "";
$results = $conn -> query($SQL);
if($results -> num_rows == 0) {
    exit("response-negative");
}

$markLink = "../../../../data/users/posts/local/post-marks/";
$commentLink = "../../../../data/users/posts/local/post-comments/";
while($row = $results -> fetch_assoc()){

    /* Logic assumption: 1 means that the sender was actually the place and we further check in the "else" statement if we don't have already saved the value. Otherwise, we make a request and get it. */
    if($row['senderID'] != 1){
    	$userConn = globalAccess($folsys);
    	$SQL = "SELECT CONCAT(user.firstName, ' ', user.lastName) AS 'name', gender.value AS 'gender'
            FROM user
            INNER JOIN gender
            ON user.genderID = gender.genderID
            WHERE user.userID = " . $row['senderID'] . "
            LIMIT 1";
    	$result = $userConn -> query($SQL);
    	if($result -> num_rows > 0){
    		$result = $result -> fetch_assoc();
    		$row['senderName'] = $result['name'];
    		$row['senderGender'] = $result['gender'];
    	}
    	else{
    		$row['senderName'] = "Skycity user";
    		$row['senderGender'] = "neutral";
    	}
    	$userConn -> close();
    } 
    else{
    	if($placeName != ""){
    		$row['senderName'] = $placeName;
    	}
    	else{
    		$placeConn = globalAccess($folsys);
    		$SQL = "SELECT name FROM place WHERE placeID = '" . $placeID . "' LIMIT 1";
    		$result = $placeConn -> query($SQL);
    		if($result -> num_rows > 0){
    			$result = $result -> fetch_assoc();
    			$row['senderName'] = $placeName = $result['name'];
    		}
    		else{
    			$row['senderName'] = $placeName = "Skycity place";
    		}
    		$row['senderGender'] = "neutral";
    		$placeConn -> close();
    	}
    }

    /* Get the trivial marks & comments data -- Ultra cases checked */
    if(!file_exists($markLink . $placeID . "-" . $row['postID'])){
	        $readFile = fopen($markLink . $placeID . "-" . $row['postID'], "r");
	        $markNumber = fgets($readFile);
	        $markNumber = filter_var($markNumber, FILTER_SANITIZE_NUMBER_INT);
	        $row['marks'] = $markNumber;
	        $row['isSelfMarked'] = strpos(fgets($readFile), "," . $userID . ",") !== false;
	        fclose($readFile);
        }
    else{
	fopen($markLink . $placeID . "-" . $row['postID'], "w");
        $row['marks'] = 0;
        $row['isSelfMarked'] = false;
    }

    if(!file_exists($commentLink . $placeID . "-" . $row['postID'])){
    		$readFile = fopen($commentLink . $placeID . "-" . $row['postID'], "r");
	  	$commentNumber = fgets($readFile);
	  	$commentNumber = filter_var($commentNumber, FILTER_SANITIZE_NUMBER_INT);
	  	$row['comments'] = $commentNumber;
	  	fclose($readFile);
        }
	else{
		fopen($commentLink . $placeID . "-" . $row['postID'], "w");
		$row['comments'] = 0;
	}

    /* Retrieve the taggers if there are any. */
    if(strpos($row['attachment'],'tag') !== false) {
        $row['taggers'] = retrieveTaggers($placeID, $row['postID']);
    }

    // Unsecure these strings (if they contain a '\'' character)
    $row['senderName'] = unsecureString($row['senderName']);
    $row['content'] = unsecureString($row['content']);


    /* Retrieve the menu-item if there is one. */
    if(strpos($row['attachment'],'menu-item') !== false){
    	$menuItemLink = "../../../../data/users/posts/local/post-menu-item/" . $placeID . "-" . $row['postID'];
    	$readFile = fopen($menuItemLink, "r");
    	$menuItemID = fgets($readFile);
    	$row['menuItemID'] = $menuItemID;
    	// TODO
    }
    
    $output[] = $row;
}
print(json_encode($output));

function retrieveTaggers($placeID, $postID){
    $link = "../../../../data/users/posts/local/post-tags/";
    $readFile = fopen($link . $placeID . "-" . $postID, "r");

    $output = "";
    while(!feof($readFile)) {
        $readLine = fgets($readFile);
        $strlen = strlen($readLine);
        $id = "";
        $newReadLine = "";
        for( $i = 0; $i <= $strlen; $i++ ) {
            $char = substr( $readLine, $i, 1 );
            if(!is_numeric( $char ) ) {
                $newReadLine = substr($readLine, $i + 1, $strlen - $i - 1);
                break;
            }
            $id .= $char;
        }
        $row['taggerID'] = $id;
        $row['name'] = unsecureString($newReadLine);
        $output[] = $row;
    }

    fclose($readFile);
    return json_encode($output);
}

$conn -> close();
?>