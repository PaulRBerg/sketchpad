<?php
/**
 * Created by PhpStorm.
 * User: razvanpaul
 * Date: 03/01/16
 * Time: 21:38
 */

include '../../../../../../../libs/skycity-functions.php';
$conn = globalAccess($localsys);

// classicsys
$senderID = $_POST['senderID'];
$placeID = (int) $_POST['placeID'];
$content = mysql_escape_mimic(secureString($_POST['content']));
$attachment = $_POST['attachment'];
$isGlobal = $_POST['isGlobal'];

$SQL = "INSERT INTO place_".$placeID."_post (senderID, content, attachment)
        VALUES ('" . $senderID . "', '" . $content . "', '" . $attachment . "')";
$conn -> query($SQL) or exit('response-negative');
$postID = $conn -> insert_id;

$markFile = fopen("/home/r35755opti/public_html/skycity/data/users/posts/local/post-marks/" . $placeID . "-" . $postID, "w");
fwrite($markFile, "0\n");
fclose($markFile);

$commentFile = fopen("/home/r35755opti/public_html/skycity/data/users/posts/local/post-comments/" . $placeID . "-" . $postID, "w");
fwrite($commentFile, "0");
fclose($commentFile);


/* tagsys */
if(strpos($attachment, "menu-item") !== false){
     $tags = $_POST['tags'];
     $tagFile = fopen("/home/r35755opti/public_html/skycity/data/users/posts/local/post-tags/". $placeID . "-" . $postID, "w");
     fwrite($tagFile, secureString($tags));
     fclose($tagFile);

     // SEND NOTIFICATIONS FOR TAG -> DO NOT FORG
     $parts = explode("\n", $tags); 
     $type = $isGlobal ? "global" : "local";
     foreach($parts as $part){
         $smallerPart = explode("-", $part);
         enlargeUserActivity($senderID, $placeID, $smallerPart[0], $type);
     }
}

/* picturesys */
if(strpos($attachment, "picture") !== false){
	$filePath = '../../../../../data/users/posts/local/post-pictures/' . $placeID . '-' . $postID . '.jpg';
	if(move_uploaded_file($_FILES['imageFile']['tmp_name'], $filePath)){
		echo 'response-ok';
	} 
	else{
		$SQL = "DELETE FROM place_".$placeID."_post WHERE postID = '" . $postID . "' ";
		$conn -> query($SQL);
		echo 'response-negative';
	}
}



/* videosys */
if(strpos($attachment, "video") !== false){
	// TODO
}



/* menuitemsys */
if(strpos($attachment, "menu-item") !== false){
	$menuItemFile = fopen("/home/r35755opti/public_html/skycity/data/users/posts/local/post-menu-item/" . $placeID . "-" . $postID, "w");
	fwrite($menuItemFile, $_POST['menuItemID']);
	fclose($menuItemFile);
}



/* global */
if($isGlobal){
    	$conn = globalAccess($postsys);
    	$configuration = json_encode(["isTweet" => false, "isUser" => true, "placeID" => $placeID, "postID" => $postID]);
    	$SQL = "INSERT INTO postUser (senderID, configuration)
            VALUES ('" . $senderID . "', '" . $configuration . "')";
    	$conn -> query($SQL) or exit('response-negative');

    	enlargeUserActivity($senderID, $placeID, $conn -> insert_id, "global");
}
else{
	enlargeUserActivity($senderID, $placeID, $postID, "local");
}


echo $postID;
$conn -> close();
?>