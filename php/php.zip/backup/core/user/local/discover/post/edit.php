<?php

include '../../../../../../../libs/skycity-functions.php';
$conn = globalAccess($localsys);

$placeID = $_POST['placeID'];
$postID = (int) $_POST['postID'];
$content = secureString($_POST['content']);

$SQL = "UPDATE place_" . $placeID . "_post SET content = '" . $content . "' WHERE postID = " . $postID . " ";

if($conn -> query($SQL)){
	echo 'response-ok';
}
else{
	echo 'response-negative';
}

$conn -> close();
?>