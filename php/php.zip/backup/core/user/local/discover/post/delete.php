<?php

include '../../../../../../../libs/skycity-functions.php';
$conn = globalAccess($postsys);
$localConn = globalAccess($localsys);

$userID = $_POST['userID'];
$placeID = (int) $_POST['placeID'];
$postID = (int) $_POST['postID'];
$globalPostID = $_POST['globalPostID'];

if(empty($globalPostID)){
	$configuration = json_encode(["isTweet"=>false,"isUser"=>true,"placeID"=>$placeID,"postID"=>$postID]);
	$SQL = "SELECT postUserID FROM postUser WHERE configuration = '" . $configuration . "' LIMIT 1";
	$result = $conn -> query($SQL);
	//var_dump($result);
	if($result -> num_rows > 0){
		$result = $result -> fetch_assoc();
		$globalPostID = $result['postUserID'];
	}
}


/* L.O. 1: If it is global, delete it from the 'postUser' table */
if(!empty($globalPostID)){
	$SQL = "DELETE FROM postUser WHERE postUserID = " . $globalPostID . " ";
	$conn -> query($SQL);
}

/* Classic removal */
$SQL = "DELETE from place_" . $placeID . "_post WHERE postID = " . $postID . "";
$localConn -> query($SQL);

$markLink = "../../../../../data/users/posts/local/post-marks/" . $placeID . "-" . $postID;
$commentLink = "../../../../../data/users/posts/local/post-comments/" . $placeID . "-" . $postID;
$tagLink = "../../../../../data/users/posts/local/post-tags/" . $placeID . "-" . $postID;
$pictureLink = "../../../../../data/users/posts/local/post-pictures/" . $placeID . "-" . $postID  . "jpg";
$videoLink = "../../../../../data/users/posts/local/post-videos/";

if(file_exists($markLink))unlink($markLink);
if(file_exists($commentLink))unlink($commentLink);
if(file_exists($tagLink))unlink($tagLink);
if(file_exists($pictureLink))unlink($pictureLink);
//unlink($videoLink . $placeID . "-" . $postID . " jpg); 

/* L.O. 2: Remove it from the 'activity' files used for cache */
if(!empty($globalPostID)){
	belittleUserActivity($userID, $placeID, $globalPostID, "global");
}
else{
	belittleUserActivity($userID, $placeID, $postID, "local");
}

$conn -> close();
$localConn -> close();
?>