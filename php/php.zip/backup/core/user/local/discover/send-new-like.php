<?php

include '../../../../../../SkycityFunctions.php';

$PlaceID = $_POST['PlaceID'];
$PostID = $_POST['PostID'];
$UserID = $_POST['UserID'];
$DestinationID = $_POST['PosterID'];

$link = "../../../../Data/Users/Posts/PostLikes/";

$readFile = fopen($link . $PlaceID . "-" . $PostID, "r");

$conn = globalAccess();

$number = fgets($readFile);
$readLine = fgets($readFile);
ob_end_clean();
if(strpos($readLine, "," . $UserID . ",") !== false){
	fclose($readFile);
	$newNumber = filter_var($number, FILTER_SANITIZE_NUMBER_INT);
	$newNumber = $newNumber - 1;
	$newNumber = $newNumber . "\n";
	$writeFile = fopen($link . $PlaceID . "-" . $PostID, "w");
	$readLine = str_replace($UserID.",", "", $readLine);
	fwrite($writeFile, $newNumber . $readLine);
	fclose($writeFile);
	echo "already";
	if($UserID !== $DestinationID){
		$sql = "DELETE FROM Place_" . $PlaceID . "_Notifications WHERE SenderID = " . $UserID . " AND DestinationID = " . $DestinationID . " AND Content = '" . $PostID . "' AND Type = 1";
		$conn -> query($sql);
	}
}
else{
	fclose($readFile);
	$newNumber = filter_var($number, FILTER_SANITIZE_NUMBER_INT);
	$newNumber = $newNumber + 1;
	$newNumber = $newNumber . "\n";
	$writeFile = fopen($link . $PlaceID . "-" . $PostID, "w");
	fwrite($writeFile, $newNumber . $readLine . $UserID . ",");
	fclose($writeFile);
	if($UserID !== $DestinationID){
		$SQL = "SELECT SenderID FROM Place_" . $PlaceID . "_Notifications WHERE SenderID = '" . $UserID . "' AND DestinationID = '" . $DestinationID . "' AND Content = '" . $PostID . "' AND Type = 1";
		$results = $conn -> query($SQL);
		
		if($results -> num_rows == 0){
			$SQL = "INSERT INTO Place_" . $PlaceID . "_Notifications (SenderID, DestinationID, Type, Content, Seen) SELECT * FROM (SELECT " . $UserID . ", " . $DestinationID . ", 1, '" . $PostID . "', 0) AS tmp WHERE NOT EXISTS (SELECT SenderID, DestinationID, Content, Type FROM Place_" . $PlaceID . "_Notifications WHERE SenderID = " . $UserID . " AND DestinationID = " . $DestinationID . " AND Content = '" . $PostID . "' AND Type = 1) LIMIT 1";
			$conn -> query($SQL);
		
			$SQL = "SELECT Attachment FROM Place_". $PlaceID ."_Posts WHERE ID = '" . $PostID . "' LIMIT 1";
			$results = $conn -> query($SQL) -> fetch_assoc();
			
			if(strpos($results['Attachment'],'tag') !== false) {
	    			$link = "../../Data/Users/Posts/PostTags/";
				$readFile = fopen($link . $PlaceID . "-" . $PostID, "r");
		
				while(!feof($readFile)) {
					$readLine = fgets($readFile);
					$strlen = strlen($readLine);
					$mID = "";
					for($i = 0; $i <= $strlen; $i++ ) {
						$char = substr( $readLine, $i, 1 );
						if(!is_numeric( $char ) ) { 
							$newReadLine = substr($readLine, $i + 1, $strlen - $i - 1);
							break;
						}
						$mID .= $char;
					}
					if($UserID !== $mID){
						$SQL = "INSERT INTO Place_" . $PlaceID . "_Notifications (SenderID, DestinationID, Type, Content, Seen) VALUES ('" . $UserID . "', '" . $mID . "', 5, '" . $PostID . "', 0)";
						$conn -> query($SQL);
					}
				}
				
				
				fclose($readFile);
			}
		
		}
	}
	
	/*
	$SQL = "SELECT DeviceToken FROM Users WHERE ID = '" . $DestinationID . "' LIMIT 1";
	$results = $conn -> query($SQL) -> fetch_assoc();
	$deviceToken = $results['DeviceToken'];
	
	if(!empty($deviceToken)){
		include '../../../../SkycityClasses.php';
		$obj = new APNS_Push();
		
		if($obj -> connectToAPNS()){
			$messageID = $PostID . $DestinationID;
			$payload = '{"aps":{"alert":"Someone marked one of your posts","sound":"default","badge":1}}';
			if($obj -> sendNotification($messageID, $deviceToken, $payload)){
				$obj -> disconnectFromAPNS();
				$obj = NULL;
			}
			else{
				if($obj -> reconnectToAPNS()){
					sendNotification($messageID, $_POST['deviceToken'], $payload);
				}
				else{
					writeToLog('Failed to reconnect after 3 attempts');
				}
			}
		}
	}
	*/
}

$conn -> close();
?>