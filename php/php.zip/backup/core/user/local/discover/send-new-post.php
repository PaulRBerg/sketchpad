<?php

include '../../../../../../SkycityFunctions.php';
$conn = globalAccess();

$PlaceID = $_POST['PlaceID'];
$SenderID = $_POST['UserID'];
$Content = $_POST['Content'];
$Attachment = $_POST['Attachment'];
$Tags = $_POST['Tags'];

$sql = "SELECT Name FROM Users WHERE ID = " . $SenderID . " LIMIT 1";
$results = $conn -> query($sql);
$row = $results->fetch_assoc();

$SenderName = secureString($row['Name']);
$Content = mysql_escape_mimic(secureString($Content));

$sql = "INSERT INTO Place_" . $PlaceID . "_Posts(SenderID,Content, SenderName, Attachment) VALUES('" . $SenderID . "', '" . $Content . "', '" . $SenderName . "', '" . $Attachment . "') ";
$conn -> query($sql);

$likeLink = "../../../../Data/Users/Posts/PostLikes/";
$commentLink = "../../../../Data/Users/Posts/PostComments/";

$PostID = $conn -> insert_id;
$myLikeFile = fopen($likeLink . $PlaceID . "-" . $PostID, "w");
fwrite($myLikeFile, "0\n,");

$myCommentFile = fopen($commentLink . $PlaceID . "-" . $PostID, "w");
fwrite($myCommentFile, "0");

if(!empty($Tags)){
	$tagLink = "../../Data/Users/Posts/PostTags/";
	$myTagFile = fopen($tagLink . $PlaceID . "-" . $PostID, "w");
	fwrite($myTagFile, secureString($Tags));
	fclose($myTagFile);
	
	$parts = explode("\n", $Tags);
	foreach($parts as $part){
		$smallerPart = explode("-", $part);
		$SQL =  "INSERT INTO Place_" . $PlaceID . "_Notifications (SenderID, DestinationID, Type, Content, Seen) VALUES('" . $SenderID . "', '" . $smallerPart[0] . "', 4, '" . $PostID . "', 0)";
		$conn -> query($SQL);
	}
	
}
fclose($myLikeFile);
fclose($myCommentFile);
echo $PostID;

$conn -> close();
?>