<?php

include '../../../../../../SkycityFunctions.php';
$conn = globalAccess();

$SQL = "Select Place_" . $_POST['PlaceID'] . "_Notifications.ID, SenderID, Content, Type, Seen, TimeSent, Users.Name from Place_" . $_POST['PlaceID'] . "_Notifications INNER JOIN Users ON SenderID = Users.ID WHERE DestinationID = " . $_POST['UserID'] . " ORDER BY TimeSent DESC";
$results = $conn -> query($SQL);

$updateString = "";
if($results -> num_rows>0){
    while($row = $results->fetch_assoc()){
		if($row['Seen'] == 0)
			$updateString .= $row['ID'] . ",";
        $output[] = $row;
    }
	print(json_encode($output));
	if($updateString!==""){
		$updateString = substr($updateString, 0, -1);
		$sql = "UPDATE Place_" . $_POST['PlaceID'] . "_Notifications SET Seen = 1 WHERE ID IN (" . $updateString . ") ORDER BY FIELD (ID, " . $updateString . " )";
		$conn -> query($sql);
	}
}
else{
	echo "NO_NOTIFICATION_FOUND";
}

$conn -> close();
?>