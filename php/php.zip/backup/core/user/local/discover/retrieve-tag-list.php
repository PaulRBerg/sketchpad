<?php

include '../../../../../../SkycityFunctions.php';
$conn = globalAccess();

$PlaceID = $_POST['PlaceID'];
$PostID = $_POST['PostID'];

$link = "../../../../Data/Users/Posts/PostTags/";

$SQL = "SELECT Attachment FROM Place_" . $PlaceID ."_Posts WHERE ID = '" . $PostID . "' ";
$results = $conn -> query($SQL) -> fetch_assoc();

if(strpos($results['Attachment'],'tag') !== false){
	$readFile = fopen($link . $PlaceID . "-" . $PostID, "r");
	
	while(!feof($readFile)) {
		$readLine = fgets($readFile);
		$strlen = strlen($readLine);
		$id = "";
		for( $i = 0; $i <= $strlen; $i++ ) {
			$char = substr( $readLine, $i, 1 );
			if( ! is_numeric( $char ) ) { 
				$newReadLine = substr($readLine, $i + 1, $strlen - $i - 1);
				break;
			}
			$id .= $char;
		}
		$row['ID'] = $id;
		$row['Name'] = $newReadLine;
		$output[] = $row;
	}
}
else{
	echo 'NO_TAG_FOUND';
}

fclose($readFile);
print(json_encode($output));

$conn -> close();
?>