<?php

include '../../../../../../libs/ImageResize.php';
use \Eventviva\ImageResize;

$filePath = '../../../../Data/Users/Posts/PostPictures/';
$filePath = $filePath . basename( $_FILES['imageFile']['name']);

if(move_uploaded_file($_FILES['imageFile']['tmp_name'], $filePath)) {
	
	$filePath = editProfilePictureAndGetPath($filePath);
	
	echo 'PROFILE_UPDATED_SUCCESSFULLY';
} 
else{
	echo 'UPLOAD_FAIL_PHP_FILE';
}

function editProfilePictureAndGetPath($filePath){
	
	$newFilePath = '../../Data/Users/Posts/PostPictures/';
	$fileName = $_POST['fileName'];
	$newFilePath = $newFilePath . $fileName;
	
	rename($filePath, $newFilePath); // ASIGN THE NEW PATH TO THE NEW PICTURE
	
	return $newFilePath;
}

?>