<?php

include '../../../../../../SkycityFunctions.php';
$conn = globalAccess();

$sql = "Select COUNT(ID) as total from Place_" . $_POST['PlaceID'] . "_Notifications WHERE Seen = 0 AND DestinationID = " . $_POST['UserID'] . "";

$results = $conn -> query($sql);
$row = $results->fetch_assoc();

echo $row['total'];

$conn -> close();
?>