<?php

include '../../../../../../SkycityFunctions.php';
$conn = globalAccess();

$PlaceID = $_POST['PlaceID'];
$PostID = $_POST['PostID'];

$SQL = "Select SenderID, SenderName, Content, TimePosted, ID, Attachment from Place_" . $PlaceID . "_Posts WHERE ID = " . $PostID . " LIMIT 1";
$results = $conn -> query($SQL);

$likeLink = "../../../../Data/Users/Posts/PostLikes/";
$commentLink = "../../../../Data/Users/Posts/PostComments/";
if($results->num_rows>0){
    while($row = $results->fetch_assoc()){
		$readFile = fopen($likeLink . $PlaceID . "-" . $row['ID'], "r");
		$likeNumber = fgets($readFile);
		$likeNumber = filter_var($likeNumber, FILTER_SANITIZE_NUMBER_INT);
		$idLine = fgets($readFile);
		if(strpos($idLine, "," . $_POST['UserID'] . ",") !== false){
			$row['Liked'] = 1;
		}
		else{
			$row['Liked'] = 0;
		}
		
		$readFile = fopen($commentLink . $PlaceID . "-" . $row['ID'], "r");
		$commentNumber = fgets($readFile);
		$commentNumber = filter_var($commentNumber, FILTER_SANITIZE_NUMBER_INT);
		$row['Likes'] = $likeNumber;
		$row['Comments'] = $commentNumber;
		$row['Content'] = str_replace("?>!<?", "'", $row['Content']);
		
		$userSql = "SELECT Gender FROM Users WHERE ID = " . $row['SenderID'] . " LIMIT 1";
		$userResult = $conn -> query($userSql);
		$userRow = $userResult->fetch_assoc();
		$row['Gender'] = $userRow['Gender'];
		
		// Retrieve the taggers if there are any
		if (strpos($row['Attachment'],'tag') !== false) {
   			 $row['Taggers'] = retrieveTaggers($PlaceID, $row['ID']);
		}
		
        	$output[] = $row;
		fclose($readFile);
    }
	print(json_encode($output));
}
else{
	echo "NO_POST_FOUND";
}

function retrieveTaggers($PlaceID, $PostID){
	$link = "../../Data/Users/Posts/PostTags/";
	$readFile = fopen($link . $PlaceID . "-" . $PostID, "r");
	
	while(!feof($readFile)) {
		$readLine = fgets($readFile);
		$strlen = strlen($readLine);
		$id = "";
		for( $i = 0; $i <= $strlen; $i++ ) {
			$char = substr( $readLine, $i, 1 );
			if(!is_numeric( $char ) ) { 
				$newReadLine = substr($readLine, $i + 1, $strlen - $i - 1);
				break;
			}
			$id .= $char;
		}
		$row['ID'] = $id;
		$row['Name'] = unsecureString($newReadLine);
		$output[] = $row;	
	}
	
	fclose($readFile);
	return json_encode($output);
}


$conn -> close();
?>