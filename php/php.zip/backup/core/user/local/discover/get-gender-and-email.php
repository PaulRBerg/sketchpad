<?php

include '../../../../../../SkycityFunctions.php';
$conn = globalAccess();

$SQL = "Select Gender, Email FROM Users WHERE ID = " . $_POST['UserID'] . " LIMIT 1";
$results = $conn -> query($SQL);

if($results -> num_rows > 0){
	$row = $results -> fetch_assoc();
	if(empty($row['Gender'])){
    			$row['Gender'] = "";
    	}
    		
    	$output[] = $row;
    	print(json_encode($output));
}
else{
	echo 'NO_USER_FOUND';
}

$conn -> close();
?>