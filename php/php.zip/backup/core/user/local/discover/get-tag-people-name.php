<?php

include '../../../../../../SkycityFunctions.php';
$conn = globalAccess();

$PlaceID = $_POST['PlaceID'];
$UserID = $_POST['UserID'];

$link = "../../Data/Users/Posts/PostLikes/";

$searchString = "";

$sql = "SELECT UserID FROM Place_" . $PlaceID . "_Connections WHERE UserID != " . $UserID . " AND Visible = 1 ORDER BY TimeConnected DESC";
$results = $conn -> query($sql);

if($results->num_rows>0){
    while($row = $results->fetch_assoc()){
		$searchString.=$row['UserID'] . ",";
    }
}

$searchString = substr($searchString, 0, -1);

$sql = "SELECT ID, Name FROM Users WHERE ID IN (" . $searchString . ") ORDER BY FIELD (ID, " . $searchString . " )";
$results = $conn -> query($sql);

if($results->num_rows>0){
    while($row = $results->fetch_assoc()){
		$output[] = $row;
    }
	print(json_encode($output));
}

$conn -> close();
?>