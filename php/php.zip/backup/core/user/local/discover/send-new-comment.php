<?php

include '../../../../../../SkycityFunctions.php';
$conn = globalAccess();

$PlaceID = $_POST['PlaceID'];
$PostID = $_POST['PostID'];
$UserID = $_POST['UserID'];
$Comment = $_POST['Comment'];
$TimeSent = $_POST['TimeSent'];
$DestinationID = $_POST['PosterID'];

$link = "../../../../Data/Users/Posts/PostComments/";
$readFile = fopen($link . $PlaceID . "-" . $PostID, "r");

$number = fgets($readFile);
$readLine = "";
while(!feof($readFile)) {
	$readLine .= fgets($readFile);
}
ob_end_clean();

if($readLine !== ""){
	$readLine.= "\n";
}
$newNumber = filter_var($number, FILTER_SANITIZE_NUMBER_INT);
$newNumber = $newNumber + 1;
$newNumber = $newNumber . "\n";
fclose($readFile);

$TimeSent = strtotime("now");
$TimeSent *= 1000;
$Comment = mysql_escape_mimic(secureString($Comment));
$writeFile = fopen($link . $PlaceID . "-" . $PostID, "w");
fwrite($writeFile, $newNumber . $readLine . "N" . $UserID . " " . $TimeSent . " " . $Comment);
fclose($writeFile);

if($UserID !== $DestinationID){
	$SQL = "SELECT SenderID FROM Place_" . $PlaceID . "_Notifications WHERE SenderID = '" . $UserID . "' AND DestinationID = '" . $DestinationID . "' AND Content = '" . $PostID . "' AND Type = 2 LIMIT 1";
	$results = $conn -> query($SQL);
	
	if($results -> num_rows == 0){
		$SQL = "INSERT INTO Place_" . $PlaceID . "_Notifications (SenderID, DestinationID, Type, Content, Seen) VALUES(" . $UserID . ", " . $DestinationID . ", 2, '" . 		$PostID . "', 0)";
		$conn -> query($SQL);
	
		$SQL = "SELECT Attachment FROM Place_". $PlaceID ."_Posts WHERE ID = '" . $PostID . "' LIMIT 1";
		$results = $conn -> query($SQL) -> fetch_assoc();
		
		if(strpos($results['Attachment'],'tag') !== false) {
    			$link = "../../Data/Users/Posts/PostTags/";
			$readFile = fopen($link . $PlaceID . "-" . $PostID, "r");
	
			while(!feof($readFile)) {
				$readLine = fgets($readFile);
				$strlen = strlen($readLine);
				$mID = "";
				for( $i = 0; $i <= $strlen; $i++ ) {
					$char = substr( $readLine, $i, 1 );
					if(!is_numeric( $char ) ) { 
						$newReadLine = substr($readLine, $i + 1, $strlen - $i - 1);
						break;
					}
					$mID .= $char;
				}
				if($UserID !== $mID){
					$SQL = "INSERT INTO Place_" . $PlaceID . "_Notifications (SenderID, DestinationID, Type, Content, Seen) VALUES ('" . $UserID . "', '" . $mID . "', 6, '" . $PostID . "', 0)";
					$conn -> query($SQL);
				}
			}
			
			
			fclose($readFile);
		}
		
	}	
}
else{
	$SQL = "SELECT SenderID FROM Place_" . $PlaceID . "_Notifications WHERE SenderID = '" . $UserID . "' AND Content = '" . $PostID . "' AND Type = 6 LIMIT 1";
	$results = $conn -> query($SQL);
	
	if($results -> num_rows == 0){
		$SQL = "SELECT Attachment FROM Place_". $PlaceID ."_Posts WHERE ID = '" . $PostID . "' LIMIT 1";
		$results = $conn -> query($SQL) -> fetch_assoc();
		
		if(strpos($results['Attachment'],'tag') !== false) {
			$link = "../../Data/Users/Posts/PostTags/";
			$readFile = fopen($link . $PlaceID . "-" . $PostID, "r");
	
			while(!feof($readFile)) {
				$readLine = fgets($readFile);
				$strlen = strlen($readLine);
				$mID = "";
				for( $i = 0; $i <= $strlen; $i++ ) {
					$char = substr( $readLine, $i, 1 );
					if(!is_numeric( $char ) ) { 
						$newReadLine = substr($readLine, $i + 1, $strlen - $i - 1);
						break;
					}
					$mID .= $char;
				}
				if($UserID !== $mID){
					$SQL = "INSERT INTO Place_" . $PlaceID . "_Notifications (SenderID, DestinationID, Type, Content, Seen) VALUES ('" . $UserID . "', '" . $mID . "', 6, '" . $PostID . "', 0)";
					$conn -> query($SQL);
				}
			}
			
			
			fclose($readFile);
		}
	}
	
}


/*
$SQL = "SELECT DeviceToken FROM Users WHERE ID = '" . $DestinationID . "' LIMIT 1";
$results = $conn -> query($SQL) -> fetch_assoc();
$deviceToken = $results['DeviceToken'];

if(!empty($deviceToken)){
	include '../../../../SkycityClasses.php';
	$obj = new APNS_Push();
	
	if($obj -> connectToAPNS()){
		$messageID = $PostID . $DestinationID;
		$payload = '{"aps":{"alert":"Someone commented on one of your posts","sound":"default","badge":1}}';
		if($obj -> sendNotification($messageID, $deviceToken, $payload)){
			$obj -> disconnectFromAPNS();
			$obj = NULL;
		}
		else{
			if($obj -> reconnectToAPNS()){
				sendNotification($messageID, $_POST['deviceToken'], $payload);
			}
			else{
				writeToLog('Failed to reconnect after 3 attempts');
			}
		}
	}
}
*/

$conn -> close();
?>