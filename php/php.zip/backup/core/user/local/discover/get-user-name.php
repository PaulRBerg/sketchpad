<?php

include '../../../../../../SkycityFunctions.php';
$conn = globalAccess();

$sql = "Select Name, Gender FROM Users WHERE ID = " . $_POST['UserID'] . " LIMIT 1";

$results = $conn -> query($sql);

if($results->num_rows>0){
	$row = $results -> fetch_assoc();
	$row['Name'] = unsecureString($row['Name']);
    	echo $row['Name'];
}
else{
	echo "NO_USER_FOUND";
}

$conn -> close();
?>