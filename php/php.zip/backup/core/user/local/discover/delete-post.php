<?php

include '../../../../../../../libs/skycity-functions.php';
$conn = globalAccess($universalsys);

$placeID = $_POST['placeID'];
$postID = $_POST['postID'];

if($_POST['isGlobal']){
	$SQL = "SELECT configuration FROM r35755op_skycity_postsys.postUser WHERE postUserID = " . $postID . " LIMIT 1";
	$localPostID = $conn -> query($SQL) -> fetch_assoc()['configuration']['postID'];
	$SQL = "DELETE FROM r35755op_skycity_postsys.postUser WHERE postUserID = " . $postID . " ";
	$conn -> query($SQL);
	$postID = $localPostID;
}
$SQL = "DELETE from place_" . $placeID . "_post WHERE ID = " . $postID . "";
$conn -> query($SQL);


$markLink = "../../../../../data/users/posts/local/post-marks/";
$commentLink = "../../../../../data/users/posts/local/post-comments/";
$tagLink = "../../../../../data/users/posts/local/post-tags/";
$pictureLink = "../../../../../data/users/posts/local/post-pictures/";
$videoLink = "../../../../../data/users/posts/local/post-videos/";

unlink($commentLink . $placeID . "-" . $postID);
unlink($likeLink . $placeID . "-" . $postID);
unlink($tagLink . $placeID . "-" . $postID);
unlink($pictureLink . $placeID . "-" . $postID  . ".jpg");
unlink($videoLink . $placeID . "-" . $postID . ".jpg");

$conn -> close();
?>