<?php

include '../../../../../../SkycityFunctions.php';
$conn = globalAccess();

$PlaceID = $_POST['PlaceID'];
$PostID = $_POST['PostID'];

$link = "../../../../Data/Users/Posts/PostLikes/";

$readFile = fopen($link . $PlaceID . "-" . $PostID, "r");

$number = fgets($readFile);
$readLine = fgets($readFile);

$id = explode(',', $readLine);
$searchString = "";

foreach ($id as &$value) {
    //$output[]['SenderID'] = $value;
	if($value !== "")
		$searchString.=$value.",";
}

$searchString = substr($searchString, 0, -1);

$sql = "SELECT Name FROM Users WHERE ID IN (" . $searchString . ") ORDER BY FIELD (ID, " . $searchString . " )";
$results = $conn -> query($sql);

if($results->num_rows>0){
	$aux = 1;
    while($row = $results->fetch_assoc()){
		//$output[]['SenderName'] = $row['Name'];
		$row['SenderID'] = $id[$aux];
		$aux +=1;
		$output[] = $row;
    }
	print(json_encode($output));
}
fclose($readFile);

$conn -> close();
?>