<?php

include '../../../../../../SkycityFunctions.php';
$conn = globalAccess();

$PlaceID = $_POST['PlaceID'];
$PostID = $_POST['PostID'];

$link = "../../../../Data/Users/Posts/PostComments/";

$readFile = fopen($link . $PlaceID . "-" . $PostID, "r");
$number = fgets($readFile);
$newNumber = filter_var($number, FILTER_SANITIZE_NUMBER_INT);

while(!feof($readFile)) {
	$readLine = fgets($readFile);
	$strlen = strlen($readLine);
	
	$id = "";
	$timeSent = "";
	$comment = "";
	$current = 0;
	
	$isNew = false;
	for($i = 0; $i <= $strlen; $i++ ) {
		$char = substr($readLine, $i, 1);
		if($i == 0){
			if(!is_numeric($char)){
				$isNew = true;
				continue;
			}
		}
		if($isNew){
			if($char == " " && $current < 2) { 
				$current ++;
			}
			else{
				if($current == 0){
					$id .= $char;
				}
				else if($current == 1){
					$timeSent .= $char;
				}
				else if($current == 2){
					$comment .= $char;
				}
			}
		}
		else{
			if($char == " " && $current < 1) { 
				$current ++;
			}
			else{
				if($current == 0){
					$id .= $char;
				}
				else if($current == 1){
					$comment.= $char;
				}
			}
		}
	}
	
	$SQL = "SELECT Name FROM Users WHERE ID = " . $id . " LIMIT 1";
	$results = $conn -> query($SQL);
	$lineRes = $results -> fetch_assoc();
	$row['SenderName'] = $lineRes['Name'];
	$row['SenderID'] = $id;
	$row['TimeSent'] = $timeSent;
	$row['Comment'] = unsecureString($comment);
	$output[] = $row;
}

fclose($readFile);
print(json_encode($output));

$conn -> close();
?>