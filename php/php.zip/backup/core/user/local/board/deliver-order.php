<?php 

include '../../../../../../SkycityFunctions.php';
$conn = globalAccess();

$PlaceID = $_POST['PlaceID'];
$SenderID = $_POST['SenderID'];
$TableNumber = $_POST['TableNumber'];
$TimeSent = $_POST['TimeSent'];
$MenuItemsIDs = $_POST['MenuItemsIDs'];
$Quantities = $_POST['Quantities'];
$Specifications = mysql_escape_mimic($_POST['Specifications']);

$SQL = "INSERT INTO Place_" . $PlaceID . "_Orders(SenderID, TableNumber, TimeSent, MenuItemsIDs, Quantities, Specifications, Taken) VALUES('" . $SenderID . "', '" . $TableNumber . "', '" . $TimeSent . "', '" . $MenuItemsIDs . "', '" . $Quantities . "', '" . $Specifications . "', 0) ";
$conn -> query($SQL);

echo 'ORDER_DELIVERED_SUCCESSFULLY';
$conn -> close();
?>