<?php

include '../../../../../../SkycityFunctions.php'
$conn = globalAccess();

$PlaceID = $_POST['PlaceID'];
$SenderID = $_POST['SenderID'];
$TimeSent = $_POST['TimeSent'];
$Stage = $_POST['StagePart'];

$SQL = "UPDATE Place" . $PlaceID . "_Orders SET Stage = '" . $Stage . "' WHERE SenderID = '" . $SenderID . "' AND TimeSent = '" . $TimeSent . "' ";
$conn -> query($SQL);

echo 'UPDATED_SUCCESSFULLY';
$conn -> close();
?>