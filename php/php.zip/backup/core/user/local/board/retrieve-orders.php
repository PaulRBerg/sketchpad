<?php

include '../../../../../../SkycityFunctions.php';
$conn = globalAccess();

$PlaceID = $_POST['PlaceID'];
$UserID = $_POST['UserID'];

$SQL = "SELECT SenderID, TableNumber, TimeSent, MenuItemsIDs, Quantities, Specifications, Taken, Stage FROM Place_" . $PlaceID . "_Orders WHERE SenderID = '" . $UserID . "' AND Taken != 2 ORDER BY ID DESC"; // 2 MEANS "CHECK" TYPE ORDER
$results = $conn -> query($SQL);

if($results -> num_rows > 0){
	while($row = $results -> fetch_assoc()){
		$output[] = $row;
	}
	print(json_encode($output));
}
else{
	echo 'NO_ORDER_FOUND';
}

$conn -> close();
?>