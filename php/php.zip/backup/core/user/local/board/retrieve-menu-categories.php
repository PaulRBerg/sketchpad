<?php 
// StateOfDay = 3 means that the products are available regardless it is day or night.

include '../../../../../../SkycityFunctions.php';
$conn = globalAccess();

$PlaceID = $_POST['PlaceID'];
$StateOfDay = $_POST['StateOfDay'];

$SQL = "SELECT ID,Name FROM Place_" . $PlaceID . "_MenuCategories WHERE StateOfDay = '" . $StateOfDay . "' OR StateOfDay = 3";
$results = $conn -> query($SQL);

$SQL = "SELECT Ordering FROM PlacesMetadata WHERE PlaceID = " . $PlaceID . " LIMIT 1";
$metadata = $conn -> query($SQL);
$metaRow = $metadata -> fetch_assoc();
if($metaRow['Ordering'] == 0){
	if($results -> num_rows > 0){
		while($row = $results -> fetch_assoc()){
			$output[] = $row;
		}
		print(json_encode($output));
	}
	else{
		echo 'NO_MENU_FOUND';
	}
}
else{
	if($results -> num_rows > 0){
		while($row = $results -> fetch_assoc()){
			$output[] = $row;
		}
		print(json_encode($output));
	}
	else{
		echo 'NO_MENU_FOUND';
	}
}


$conn -> close();
?>