<?php

include '../../../../../../SkycityFunctions.php';
$conn = globalAccess();

$PlaceID = $_POST['PlaceID'];


$SQL = "SELECT Starters FROM PlacesMetadata WHERE PlaceID = '" . $PlaceID . "' ";
$results = $conn -> query($SQL);
$starters = $results -> fetch_assoc();

if($results -> num_rows > 0 && $starters['Starters'] != 'None'){
	echo $starters['Starters'];
}
else{
	echo 'NO_STARTERS_FOUND';
}

$conn -> close();
?>