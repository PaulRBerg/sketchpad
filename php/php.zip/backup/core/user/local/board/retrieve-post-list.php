<?php
/**
 * Created by PhpStorm.
 * User: razvanpaul
 * Date: 23/01/16
 * Time: 13:13
 */

include '../../../../../../libs/skycity-functions.php';
$conn = globalAccess($localsys);

$senderID = 1;
$userID = $_POST['userID'];
$placeID = $_POST['placeID'];
$placeName = "";
$limit = $_POST['limit'];
$offset = $_POST['offset'];

$SQL = "SELECT postID, senderID, content, attachment, timePosted
        FROM place_".$placeID."_post
        WHERE senderID = '" . $senderID . "'
        LIMIT " . $limit . "
        OFFSET " . $offset . "";
$results = $conn -> query($SQL);

if($results -> num_rows == 0){
    exit("response-negative");
}

$markLink = "../../../../data/users/posts/local/post-marks/";
$commentLink = "../../../../data/users/posts/local/post-comments/";
while($row = $results -> fetch_assoc()){
    if($placeName != ""){
        $row['senderName'] = $placeName;
        $row['senderGender'] = "neutral";
    }
    else{
        $placeConn = globalAccess($folsys);
        $SQL = "SELECT name FROM place WHERE placeID = '" . $placeID . "' LIMIT 1";
        $result = $placeConn -> query($SQL); if($result -> num_rows == 0) exit("placeCONNECTION_ERROR"); $result = $result -> fetch_assoc();
        $row['senderName'] = $placeName = $result['name'];
        $row['senderGender'] = "neutral";
        $placeConn -> close();
    }

    $readFile = fopen($markLink . $placeID . "-" . $row['postID'], "r");
    $likeNumber = fgets($readFile);
    $likeNumber = filter_var($likeNumber, FILTER_SANITIZE_NUMBER_INT);
    $idLine = fgets($readFile);
    $row['marks'] = $likeNumber;
    $row['isSelfMarked'] = strpos($idLine, "," . $userID . ",") !== false;

    $readFile = fopen($commentLink . $placeID . "-" . $row['postID'], "r");
    $commentNumber = fgets($readFile);
    $commentNumber = filter_var($commentNumber, FILTER_SANITIZE_NUMBER_INT);
    $row['comments'] = $commentNumber;

    // Unsecure these strings (if they contain a '\'' character)
    $row['senderName'] = unsecureString($row['senderName']);
    $row['content'] = unsecureString($row['content']);

    $output[] = $row;
    fclose($readFile);
}
print(json_encode($output));

$conn -> close();
?>