<?php 

include '../../../../../../SkycityFunctions.php';
$conn = globalAccess();

$PlaceID = $_POST['PlaceID'];

$SQL = "SELECT ID,Name FROM Place_" . $PlaceID . "_MenuCategories ";
$results = $conn -> query($SQL);

$sql = "SELECT Ordering FROM PlacesMetadata WHERE PlaceID = " . $PlaceID . " LIMIT 1";
$metadata = $conn -> query($sql);
$metaRow = $metadata -> fetch_assoc();
if($metaRow['Ordering'] == 0){
	if($results -> num_rows > 0){
		while($row = $results -> fetch_assoc()){
			$output[] = $row;
		}
		print(json_encode($output));
	}
	else{
		echo 'NO_MENU_FOUND';
	}
}
else{
	if($results -> num_rows > 0){
		while($row = $results -> fetch_assoc()){
			$output[] = $row;
		}
		print(json_encode($output));
	}
	else{
		echo 'NO_MENU_FOUND';
	}
}

$conn -> close();
?>