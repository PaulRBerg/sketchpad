<?php

include '../../../../../../SkycityFunctions.php';
$conn = globalAccess();

$PlaceID = $_POST['PlaceID'];
$SenderID = $_POST['SenderID'];
$TableNumber = $_POST['TableNumber'];
$TimeSent = $_POST['TimeSent'];
$Payment = $_POST['Payment'];

if(empty($Payment)){
	$Payment = "";
}

$SQL = "INSERT INTO Place_" . $PlaceID . "_Orders(SenderID, TableNumber, TimeSent, Specifications, Taken) VALUES('" . $SenderID . "', '" . $TableNumber . "', '" . $TimeSent . "', '" . $Payment . "' ,2) ";
$conn -> query($SQL);

echo 'UPDATED_SUCCESSFULLY';
$conn -> close();
?>