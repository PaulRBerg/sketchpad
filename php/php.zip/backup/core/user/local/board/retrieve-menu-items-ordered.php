<?php

include '../../../../../../SkycityFunctions.php';
$conn = globalAccess();

$PlaceID = $_POST['PlaceID'];
$MenuItemsIDs = $_POST['MenuItemsIDs'];
$MenuItemsIDs = explode("-", $MenuItemsIDs);

if(empty($MenuItemsIDs)){
	echo 'NO_ORDER_FOUND';
}
else{
	foreach($MenuItemsIDs as $ID){
		if(!empty($ID)){
			$SQL = "SELECT ID, Name, Description, Price FROM Place_" . $PlaceID . "_MenuItems WHERE ID = '" . $ID . "' LIMIT 1";
			$row = $conn -> query($SQL) -> fetch_assoc();
			
			$row['Name'] = unsecureString($row['Name']);
			$row['Description'] = unsecureString($row['Description']);
			$row['Price'] = unsecureString($row['Price']);
			$output[] = $row;
		}
	
	}
	print(json_encode($output));
}


/*
$SQL = "SELECT ID, Name, Description, Price FROM Place_ " . $PlaceID . "_MenuItems WHERE ID IN ($Array) ";
$results = $conn -> query($SQL);


if($results -> num_rows > 0){
	while($row = $results -> fetch_assoc()){
		$output[] = $row;
	}
	print(json_encode($output));
}

echo 'NO_ORDER_FOUND';
*/

$conn -> close();
?>