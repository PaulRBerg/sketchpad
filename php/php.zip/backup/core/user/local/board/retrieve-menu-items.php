<?php 

include '../../../../../../SkycityFunctions.php';
$conn = globalAccess();

$PlaceID = $_POST['PlaceID'];
$Category = $_POST['Category'];

$sql = "SELECT ID,Name,Description,Price FROM Place_" . $PlaceID . "_MenuItems WHERE Category = '" . $Category . "' ";
$results = $conn -> query($sql);

if($results -> num_rows > 0){
	while($row = $results -> fetch_assoc()){
	
		$row['Name'] = unsecureString($row['Name']);
		$row['Description'] = unsecureString($row['Description']);
		$row['Price'] = unsecureString($row['Price']);		
		$output[] = $row;
	}
	print(json_encode($output));
}
else{
	echo 'NO_MENU_FOUND';
}

$conn -> close();
?>