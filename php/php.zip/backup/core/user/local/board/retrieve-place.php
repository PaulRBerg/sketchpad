<?php 

include '../../../../../../libs/skycity-functions.php';
$conn = globalAccess($folsys);

$placeID = $_POST['placeID'];
$SQL = "SELECT name, city, profile, configuration FROM place WHERE placeID = '" . $placeID . "' LIMIT 1";
$result = $conn -> query($SQL);

if($result -> num_rows > 0){
	$output = "";
	while($row = $result ->fetch_assoc()){
		$metaRow['name'] = $row['name'];
		$metaRow['city'] = $row['city'];
		
		$profile = json_decode($row['profile'], true);
		$metaRow['address'] = $profile['address'];
		$metaRow['site'] = $profile['site'];
		$metaRow['contact'] = $profile['contact'];
		$metaRow['description'] = $profile['description'];
		$metaRow['email'] = $profile['email'];
		$metaRow['maps'] = $profile['maps'];
		
		$configuration = json_decode($row['configuration'], true);
		$metaRow['menuOnline'] = $configuration['menuOnline'];
		$metaRow['ordering'] = $configuration['ordering'];
		$metaRow['paymentMethods'] = $configuration['paymentMethods'];
		$output[] = $metaRow;
	}
	print(json_encode($output));
}
else{
	echo 'response-negative';
}


$conn -> close();
?>