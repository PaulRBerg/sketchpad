<?php 

include '../../../../../SkycityFunctions.php';
$conn = globalAccess();

$PlaceID = $_POST['PlaceID'];

$SQL = "SELECT PaymentMethods FROM PlacesMetadata WHERE PlaceID = '" . $PlaceID . "' ";
$results = $conn -> query($SQL);

if($results -> num_rows > 0){
	$results = $results -> fetch_assoc();
	
	echo $results['PaymentMethods'];
}


$conn -> close();
?>