<?php

include '../../../../../SkycityFunctions.php';
$conn = globalAccess();

$PlaceID = $_POST['PlaceID'];
$UserID = $_POST['UserID'];


// html response
$SQL = "SELECT UserID from Place_" . $PlaceID . "_Connections WHERE UserID = '" . $UserID . "' LIMIT 1";
$results = $conn -> query($SQL);

if($results -> num_rows > 0){
	echo 'USER_FOUND';
}
else{
	echo 'NO_USER_FOUND';
}

$conn -> close();
?>