<?php

include '../../../../../SkycityFunctions.php';
$conn = globalAccess();

$PlaceID = $_POST['PlaceID'];
$UserID = $_POST['UserID'];


//update metadata
$userIDQueried = $UserID . ',';
$SQL =  "SELECT PlaceID FROM PlacesMetadata WHERE PlaceID = '" . $PlaceID . "' AND INSTR(People, '{$userIDQueried}') > 0 LIMIT 1 ";
$results = $conn -> query($SQL);

if($results -> num_rows == 1){
	
	$SQL =  "SELECT PeopleConnectedSince, People FROM PlacesMetadata WHERE PlaceID = '" . $PlaceID . "' ";
	$results = $conn -> query($SQL) -> fetch_assoc();
	
	$peopleConnectedSince = $results['PeopleConnectedSince'];
	$peopleConnectedSince = $peopleConnectedSince + 1;
	
	//echo '<pre>'.var_dump($peopleConnectedSince).'</pre>';
	
	$people = $results['People'];
	$people = $people . $UserID . ',';
	
	$SQL = "UPDATE PlacesMetadata SET PeopleConnectedSince = '" . $peopleConnectedSince . "', People = '" . $people . "' WHERE PlaceID = '" . $PlaceID . "' ";
	$results = $conn -> query($SQL);
}


// html response
if($_POST['Visible'] == 1){
	$Visible = 1;
}
else{
	$Visible = 0;
}

$sql = "INSERT INTO Place_" . $PlaceID . "_Connections (UserID, Visible, Valid) VALUES ('" . $UserID . "', '" . $Visible . "', 1)";
$conn -> query($sql);

echo 'CONNECTED_SUCCESSFULLY';

$conn -> close();
?>