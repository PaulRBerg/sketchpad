<?php

include '../../../../../../libs/skycity-functions.php';
$conn = globalAccess($universalsys);

$userID = $_POST['userID'];
$placeID = $_POST['placeID'];

$SQL = "SELECT r35755op_skycity_folsys.user.userID, r35755op_skycity_folsys.user.firstName AS name, r35755op_skycity_folsys.gender.value
	FROM r35755op_skycity_folsys.user
	INNER JOIN r35755op_skycity_local.place_".$placeID."_connection
	ON r35755op_skycity_folsys.user.userID = r35755op_skycity_local.place_" . $placeID . "_connection.userID
	INNER JOIN r35755op_skycity_folsys.gender
	ON r35755op_skycity_folsys.user.genderID = r35755op_skycity_folsys.gender.genderID
	WHERE r35755op_skycity_folsys.user.userID != " . $userID . "
	AND r35755op_skycity_local.place_".$placeID."_connection.visible = 1
	ORDER BY r35755op_skycity_local.place_".$placeID."_connection.timeConnected DESC";
$results = $conn -> query($SQL);
 
if($results -> num_rows > 0){
	$output = "";
	while($row = $results -> fetch_assoc()){
		$output[] = $row;
	}
	
	print(json_encode($output));
}
else{
	echo 'response-negative';
}

$conn -> close();
?>