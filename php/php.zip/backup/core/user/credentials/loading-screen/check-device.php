<?php
include '../../../../../../libs/skycity-functions.php';
$conn = globalAccess($folsys);

$deviceID = $_POST['deviceID'];
$SQL = "SELECT userID FROM device WHERE deviceID = '" . $deviceID . "' LIMIT 1";
$result = $conn -> query($SQL);

if($result -> num_rows > 0){
	$userColumn = $result -> fetch_assoc();
	$userID = $userColumn['userID'];	
	echo 'user' . '-' . $userID;
}
else{
	echo 'response-negative';
}

$conn -> close();
?>
	