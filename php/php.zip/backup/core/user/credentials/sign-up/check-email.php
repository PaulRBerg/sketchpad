<?php

/*
	Logic assumption: response-negative in this case tells that the user can't sign up with this email because it has been already registered.
*/
include '../../../../../../libs/skycity-functions.php';
$conn = globalAccess($folsys);

$SQL = "SELECT userID FROM user WHERE email = '" . $_POST['email'] . "' LIMIT 1 ";
$result = $conn -> query($SQL);

if($result -> num_rows > 0){
	echo 'response-negative';
}
else{
	echo 'response-ok';
}

$conn -> close();
?>