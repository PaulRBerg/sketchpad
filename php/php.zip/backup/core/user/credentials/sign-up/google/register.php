<?php

include '../../../../../../../libs/skycity-functions.php';
$conn = globalAccess($folsys);

$SQL = "SELECT userID FROM user WHERE googleID = '" . $_POST['googleID'] . "' LIMIT 1";
$result = $conn -> query($SQL);

if($results -> num_rows > 0){
    exit('response-negative');
}


// Mandatory variables
$googleID = $_POST['googleID'];
$password = 'google-account';
$email = $_POST['email'];
$firstName = mysql_escape_mimic(secureString($_POST['firstName']));
$lastName = mysql_escape_mimic(secureString($_POST['lastName']));
$genderID = mysql_escape_mimic($_POST['genderID']);
$social = json_encode(array("google" => $_POST['social']));
$platformID = mysql_escape_mimic($_POST['platformID']);


/* INSERT INTO DATABASE */
$SQL = "INSERT INTO user(googleID, email, password, firstName, lastName, genderID, social, platformID)
        VALUES('" . $googleID. "', '" . $email . "', '" . $password . "', '" . $firstName . "', '" . $lastName . "', '" . $genderID . "', '" . $social. "', '" . $platformID . "') ";
$conn -> query($SQL);
$userID = $conn -> insert_id;

function checkEmptiness($value){
    if(!empty($value)){
        return mysql_escape_mimic(secureString($value));
    }
    return "";
}

/* ADD THE FILES FOR ACTIVITY */
createUserActivity($userID);

echo $userID;
$conn -> close();
?>