<?php

include '../../../../../../../libs/skycity-functions.php';
$conn = globalAccess($folsys);

$userID = $_POST['userID'];
$genderID = $_POST['genderID'];

$SQL = "UPDATE user SET genderID = '" . $genderID . "' WHERE userID = '" . $userID . "'";

if($conn -> query($SQL)){
	echo 'response-ok';
}
else{
	echo 'response-negative';
}

$conn -> close();
?>