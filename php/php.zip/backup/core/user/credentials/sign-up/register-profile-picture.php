<?php

include '../../../../../../libs/image-resize.php';
use \Eventviva\ImageResize;

$filePath = '../../../../data/users/pictures/profile/';
$filePath = $filePath . basename($_FILES['imageFile']['name']);

function saveProfilePictureAndGetPath($filePath){
	$newFilePath = '../../../../data/users/pictures/profile/';
	$fileName = $_POST['fileName'];
	$newFilePath = $newFilePath . $fileName;
	rename($filePath, $newFilePath);
	
	return $newFilePath;
}

function saveThumbnail($whichOne, $filePath){
	$fileName = $_POST['fileName'];
	
	$newFilePath = "";
	$width = $height = 0;
	switch($whichOne){
		case 1 :
			$newFilePath = '../../../../data/users/pictures/thumbnail1/';
			$newFilePath = $newFilePath . $fileName;
			$width = $height = 320; 
			break;
		case 2:
			$newFilePath = '../../../../data/users/pictures/thumbnail2/';
			$newFilePath = $newFilePath . $fileName;
			$width = $height = 160;
			break;
		case 3:
			$newFilePath = '../../../../data/users/pictures/thumbnail3/';
			$newFilePath = $newFilePath . $fileName;
			$width = $height = 80;
			break;
		default:
			break;
	}
	$resizer = new ImageResize($filePath);
	$resizer -> resize($width, $height);
	$resizer -> save($newFilePath, null, 6);
}


if(move_uploaded_file($_FILES['imageFile']['tmp_name'], $filePath)) {

	$filePath = saveProfilePictureAndGetPath($filePath, $fileName);
	
	for($i = 1; $i <= 3; $i++){
		saveThumbnail($i, $filePath);
	}
	
	echo 'response-ok';
} 
else{
	echo 'response-negative';
}

?>