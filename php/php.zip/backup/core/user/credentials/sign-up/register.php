<?php

include '../../../../../../libs/skycity-functions.php';
$conn = globalAccess($folsys);

$SQL = "SELECT userID FROM user WHERE email = '" . $_POST['email'] . "' LIMIT 1";
$result = $conn -> query($SQL);

if($result -> num_rows > 0){
	echo 'response-negative';
	exit();
}

// Mandatory variables
$email = mysql_escape_mimic($_POST['email']);
$hash = mysql_escape_mimic(md5($_POST['email'] . $_POST['password']));
$firstName = mysql_escape_mimic(secureString($_POST['firstName']));
$lastName = mysql_escape_mimic(secureString($_POST['lastName']));
$genderID = $_POST['genderID'];
$platformID = $_POST['platformID'];

// Optional variables
if(!empty($_POST['city'])){
 	$city = $_POST['city'];
 	$city = mysql_escape_mimic(secureString($city));
}
else{
 	$city = "";
}

if(!empty($_POST['phone'])){
	$phone= $_POST['phone'];
	$phone = mysql_escape_mimic(secureString($phone));
}
else{
	$phone = "";
}

if(!empty($_POST['birthday'])){
 	$birthday= $_POST['birthday'];
 	$birthday = mysql_escape_mimic(secureString($birthday));
}
else{
	$birthday = "";
}

if(!empty($_POST['description'])){
	$description = $_POST['description'];
	$description = mysql_escape_mimic(secureString($description));
}
else{
	$description = "";
}

if(!empty($_POST['social'])){
	$social = $_POST['social'];
	$social = mysql_escape_mimic(secureString($social));
}
else{
	$social = "";
}
		
/* INSERT INTO DATABASE */
$SQL = "INSERT INTO user(email, password, firstName, lastName, genderID, city, birthday, phone, description, social, platformID)
        VALUES('" . $email . "', '" . $hash . "', '" . $firstName . "', '" . $lastName . "', '" . $genderID. "', '" . $city . "', '" . $birthday . "', '" . $phone . "', '" . $social . "', '" . $description . "', '" . $platformID. "') ";  
$conn -> query($SQL);

/* ADD THE FILES FOR ACTIVITY */
createUserActivity($conn -> insert_id);

echo $conn -> insert_id;
$conn -> close();
?>
