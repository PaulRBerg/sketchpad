<?php

include '../../../../../../../libs/image-resize.php';
use \Eventviva\ImageResize;

function saveProfilePictureAndGetPath(){
	$URL = $_POST['profilePicture'];
	
	if(!empty($URL)){
		$newFilePath = '../../../../../data/users/pictures/profile/';
		$fileName = $_POST['fileName'];
		$newFilePath = $newFilePath . $fileName;
	
		file_put_contents($newFilePath, file_get_contents($URL));
		
		return $newFilePath;
	}
	
	return 'URL_NOT_FOUND';
	
}

function saveThumbnail($whichOne, $filePath){
	$fileName = $_POST['fileName'];
	
	$newFilePath = "";
	$width = $height = 0;
	
	switch($whichOne){
		case 1 :
			$newFilePath = '../../../../../data/users/pictures/thumbnail1/';
			$newFilePath = $newFilePath . $fileName;
			$width = $height = 320;
			break;
		case 2:
			$newFilePath = '../../../../../data/users/pictures/thumbnail2/';
			$newFilePath = $newFilePath . $fileName;
			$width = $height = 160;
			break;
		case 3:
			$newFilePath = '../../../../../data/users/pictures/thumbnail3/';
			$newFilePath = $newFilePath . $fileName;
			$width = $height = 80;
			break;
		default:
			break;
	}
	$resizer = new ImageResize($filePath);
	$resizer -> resize($width, $height);
	$resizer -> save($newFilePath, null, 6);
}

$filePath = saveProfilePictureAndGetPath();
	
if($filePath != 'URL_NOT_FOUND'){
	for($i = 1; i <= 3; $i++){
		saveThumbnail($i, $filePath);
	}
	
		
	echo 'SUCCESS';
}
	
echo 'UPLOAD_FAIL_PHP_FILE';

?>