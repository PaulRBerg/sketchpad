<?php

include '../../../../../../../libs/skycity-functions.php';
$conn = globalAccess($folsys);

$userID = $_POST['userID'];
$friends = json_decode($_POST['friends'], true);

foreach($friends as $friend){
	$SQL = "INSERT INTO connectionUser(userID1, userID2) VALUES('" . $userID . "', '" . $friend['userID'] . "') ";
	if($conn -> query($SQL) == false){
		exit("response-negative");
	}
}
$conn -> close();
?>