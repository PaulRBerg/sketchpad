<?php

include '../../../../../../../libs/skycity-functions.php';
$conn = globalAccess($folsys);

$SQL = "SELECT userID FROM user WHERE facebookID = '" . $_POST['facebookID'] . "' LIMIT 1";
$result = $conn -> query($SQL);

if($results -> num_rows > 0){
    exit('response-negative');
}


// Mandatory variables
$facebookID = $_POST['facebookID'];
$password = 'facebook-account';
$firstName = mysql_escape_mimic(secureString($_POST['firstName']));
$lastName = mysql_escape_mimic(secureString($_POST['lastName']));
$genderID = mysql_escape_mimic($_POST['genderID']);
$social = json_encode(array("facebook" => $_POST['social']));
$platformID = mysql_escape_mimic($_POST['platformID']);

// Optional variables
$email = checkEmptiness($_POST['email']);
$city = checkEmptiness($_POST['city']);
$birthday = checkEmptiness($_POST['birthday']);
$description= checkEmptiness($_POST['description']);

/* INSERT INTO DATABASE */
$SQL = "INSERT INTO user(facebookID, email, password, firstName, lastName, genderID, city, birthday, social, description, platformID)
        VALUES('" . $facebookID. "', '" . $email . "', '" . $password . "', '" . $firstName . "', '" . $lastName . "', '" . $genderID . "', '" . $city . "', '" . $birthday . "', '" . $social. "', '" . $description . "', '" . $platformID . "') ";
$conn -> query($SQL);

if(!empty($_POST['friends'])){
	$output[] = array("userID" => $conn -> insert_id);
	$friends = json_decode($_POST['friends'], true);
	foreach($friends as $friend){
		$key = array_search($friend, $friends);
		$SQL = "SELECT userID FROM user WHERE facebookID = '" . $friend['id'] . "' LIMIT 1";
		$result = $conn -> query($SQL);
		$result = $result -> fetch_assoc();
		$friend['userID'] = $result['userID'];
		$friend['selected'] = true;
		$friends[$key] = $friend;
	}
	$output[] = $friends;
	echo json_encode($output);
}
else{
	echo $conn -> insert_id;
}
$userID = $conn -> insert_id;

function checkEmptiness($value){
    if(!empty($value)){
        return mysql_escape_mimic(secureString($value));
    }
    return "";
}

/* ADD THE FILES FOR ACTIVITY */
createUserActivity($userID);

$conn -> close();
?>