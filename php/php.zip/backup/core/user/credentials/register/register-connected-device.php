<?php

include '../../../../../../libs/skycity-functions.php';
$conn = globalAccess($folsys);

$userID = $_POST['userID'];
$deviceID = $_POST['deviceID'];

$SQL = "SELECT userID FROM device WHERE deviceID = '" . $deviceID . "' ";
$results = $conn -> query($SQL);

if($results -> num_rows > 0){
	$SQL = "UPDATE device SET userID = '" . $userID . "' WHERE deviceID = '" . $deviceID .  "' ";
	$conn -> query($SQL);
}
else{
	$SQL = "INSERT INTO device(userID, deviceID) VALUES ('" . $userID . "', '" . $deviceID . "') ";
	$conn -> query($SQL);
}

echo 'response-ok';
$conn -> close();
?>