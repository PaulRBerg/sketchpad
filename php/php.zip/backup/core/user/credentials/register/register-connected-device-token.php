<?php

include '../../../../../../libs/skycity-functions.php';
$conn = globalAccess($folsys);

$userID = $_POST['userID'];
$deviceToken = $_POST['deviceToken'];

$SQL = "UPDATE user SET deviceToken = '" . $deviceToken . "' WHERE userID = '" . $userID . "' ";
if($conn -> query($SQL)){
	echo 'response-ok';
}
else{
	echo 'response-negative';
}

$conn -> close();
?>