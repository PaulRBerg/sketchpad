<?php

include '../../../../../../libs/skycity-functions.php';
$conn = globalAccess($folsys);

$facebookID = $_POST['facebookID'];
$SQL = "SELECT userID FROM user WHERE facebookID = '" . $facebookID . "' LIMIT 1";
$result = $conn -> query($SQL);

if($result -> num_rows > 0){
	$userColumn = $result -> fetch_assoc();
	$userID = $userColumn['userID'];
	
	echo 'user' . '-' . $userID;
}
else{
	echo 'response-negative';
}

$conn -> close();
?>