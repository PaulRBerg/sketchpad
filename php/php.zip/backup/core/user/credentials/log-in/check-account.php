<?php

include '../../../../../../libs/skycity-functions.php';
$conn = globalAccess($folsys);

$email = $_POST['email'];
$password = $_POST['password'];
$hash = md5($email . $password);

$SQL = "SELECT userID FROM user WHERE email = '" . $email . "' and password = '" . $hash ."' LIMIT 1";
$result = $conn -> query($SQL);

if($result -> num_rows > 0){
	$userColumn = $result -> fetch_assoc();
	$userID = $userColumn['userID'];
	
	echo 'user' . '-' . $userID;
}
else{
	echo "response-negative";
}

$conn -> close();
?>