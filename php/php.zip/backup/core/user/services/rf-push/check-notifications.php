<?php

include '../../../../../../SkycityFunctions.php';
$conn = globalAccess();

$SQL = "Select COUNT(ID) as total from Place_" . $_POST['PlaceID'] . "_Notifications WHERE Seen = 0 AND ID > " . $_POST['LastID'] . " AND DestinationID = " . $_POST['UserID'] . "";
$results = $conn -> query($SQL);
$row = $results->fetch_assoc();

$sql = "Select ID as lastID from Place_" . $_POST['PlaceID'] . "_Notifications ORDER BY ID DESC LIMIT 1";
$results = $conn -> query($sql);
$last = $results->fetch_assoc();

echo $row['total'] . " " . $last['lastID'];

$conn -> close();
?>