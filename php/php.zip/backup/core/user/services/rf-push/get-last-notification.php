<?php

include '../../../../../../SkycityFunctions.php';
$conn = globalAccess();

$SQL = "Select Type, Users.Name, Content from Place_" . $_POST['PlaceID'] . "_Notifications INNER JOIN Users ON SenderID = Users.ID WHERE Seen = 0 AND DestinationID = " . $_POST['UserID'] . " ORDER BY Place_" . $_POST['PlaceID'] . "_Notifications.ID DESC LIMIT 1";
$results = $conn -> query($SQL);
if($results->num_rows>0){
    while($row = $results->fetch_assoc()){
		$output[] = $row;
    }
	print(json_encode($output));
}
else{
	echo "NO_NOTIFICATIONS";
}

$conn -> close();
?>