<?php

include '../../../../../../libs/skycity-functions.php';
$conn = globalAccess();

$PlaceID = $_POST['PlaceID'];
$Place = Place_ . '" $PlaceID . "' . _Messages;
$UserID = $_POST['UserID'];

//$sql = "SELECT SenderID,TimeSent,Type,Message,Additional FROM Place_" . $PlaceID . "_Messages WHERE DestinationID = '" . $UserID . "' ";

$SQL = "SELECT Users.Name, Place_" . $PlaceID . "_Messages.SenderID, Place_" . $PlaceID . "_Messages.TimeSent
	,Place_" . $PlaceID . "_Messages.Type, Place_" . $PlaceID . "_Messages.Message, Place_" . $PlaceID . "_Messages.Additional
	FROM Place_" . $PlaceID . "_Messages
	INNER JOIN Users
	ON Users.ID = Place_" . $PlaceID . "_Messages.SenderID
	WHERE Place_" . $PlaceID . "_Messages.DestinationID = '" . $UserID . "' ";
$results = $conn -> query($SQL);

if($results -> num_rows > 0){
	while($row = $results -> fetch_assoc()){
		$row['Message'] = str_replace("?>!<?", "'", $row['Message']);
		$output[] = $row;
	} 
	$sql = "DELETE FROM Place_" . $PlaceID . "_Messages WHERE DestinationID = '" . $UserID . "' ";
	$conn -> query($sql);
	print(json_encode($output));
}
else{
	echo 'NO_MESSAGE_FOUND';
}
$conn -> close();
?>