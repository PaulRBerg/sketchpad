<?php

include '../../../../../../libs/skycity-functions.php';
$conn = globalAccess($localsys);

$placeID = $_POST['placeID'];
$userID = $_POST['userID'];
$visible = $_POST['visible'];

$SQL = "SELECT userID FROM place_" . $placeID . "_connection WHERE userID = '" . $userID . "' LIMIT 1";
$result = $conn -> query($SQL);

if($result -> num_rows == 0){
	$SQL = "INSERT INTO place_" . $placeID . "_connection(userID, visible, valid) VALUES('" . $userID . "', '" . $visible . "', 1) ";
	$conn -> query($SQL);
}

$conn -> close();
?>