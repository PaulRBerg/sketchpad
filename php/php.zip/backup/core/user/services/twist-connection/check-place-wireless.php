<?php

include '../../../../../../libs/skycity-functions.php';
$conn = globalAccess($folsys);

$bssid = $_POST['bssid'];
$SQL = "SELECT placeID, name FROM place WHERE INSTR(bssid, '{$bssid}') > 0 LIMIT 1";
$result = $conn -> query($SQL);

if($result -> num_rows > 0){
	$place = $result -> fetch_assoc();
	echo $place['placeID'] . '-' . $place['name'];
}
else{
	echo 'response-negative';
}

$conn -> close();
?>