<?php

include '../../../../../../libs/skycity-functions.php';
$conn = globalAccess();

$coordinates = explode("-", $_POST['coordinates']);
$latitude = $coordinates[0];
$longitude = $coordinates[1];

$SQL = "SELECT placeID, name FROM place WHERE latitudeMin <= '" . $latitude . "' AND latitudeMax >= '" . $latitude . "' AND longitudeMin <= '" . $longitude . "' AND longitudeMax >= '" . $longitude . "' LIMIT 1";
$result = $conn -> query($SQL);

if($result -> num_rows > 0){
	$place = $result -> fetch_assoc();
	echo $place['placeID'] . '-' . $place['name'];
}
else{
	echo 'response-negative';
}

$conn -> close();
?>