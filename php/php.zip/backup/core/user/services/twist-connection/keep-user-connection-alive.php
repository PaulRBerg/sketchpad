<?php

include '../../../../../../libs/skycity-functions.php';
$conn = globalAccess($localsys);

$placeID = $_POST['placeID'];
$userID = $_POST['userID'];

$SQL = "UPDATE place_" . $placeID . "_connection SET valid = 1 WHERE userID = '" . $userID . "' ";
$result = $conn -> query($SQL);

$conn -> close();
?>