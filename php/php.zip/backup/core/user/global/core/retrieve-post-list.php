<?php

/*
	OLD Logic assumption: the first SELECTs at the beginning of this PHP has the following rules:
	- Try to get a total amount of 10 posts
	- If there aren't 5 posts of usertype, try to get hL + (hL - x) placeTypes by setting the limit with the previous value, where hL = half of the given limit and 
		x = the number of post retrieved from the user table
	- Vice versa for placetype
	
	
	Logic assumption 1: if $configuration['isUser'] is true, it is a post from the postUser table. Otherwise, it is a simple postPlace.
	Which can be either a classic post, either a new and enhanced tweet. Observation: senderID = 1 in the place_x_post table also means that it is a post from the place
	
	Logic assumption 2: if a post is usertype, then the placeID in the configuration array plays two roles. The first one is when it says
	in which was the post made(classic) and the second one which place has the user targeted(tweet).
*/

include '../../../../../../libs/skycity-functions.php';
$conn = globalAccess($universalsys);
$connectionError = "CONNECTION_ERROR";

$userID = $_POST['userID'];
$limit = $_POST['limit'];
$offset = $_POST['offset'];

$SQL = "SELECT r35755op_skycity_postsys.postUser.postUserID AS 'globalPostID', r35755op_skycity_postsys.postUser.senderID AS 'senderID',
	   r35755op_skycity_postsys.postUser.configuration AS 'configuration', r35755op_skycity_postsys.postUser.timePosted AS'timePosted'
	FROM r35755op_skycity_postsys.postUser
	INNER JOIN r35755op_skycity_folsys.connectionUser
	ON r35755op_skycity_postsys.postUser.senderID = r35755op_skycity_folsys.connectionUser.userID2
	WHERE r35755op_skycity_folsys.connectionUser.userID1 = '" . $userID . "'
	
	UNION

	SELECT r35755op_skycity_postsys.postPlace.postPlaceID AS 'globalPostID', r35755op_skycity_postsys.postPlace.senderID AS 'senderID',
	   r35755op_skycity_postsys.postPlace.configuration AS 'configuration', r35755op_skycity_postsys.postPlace.timePosted AS 'timePosted'
	FROM r35755op_skycity_postsys.postPlace
	INNER JOIN r35755op_skycity_folsys.connectionPlace
	ON r35755op_skycity_postsys.postPlace.senderID = r35755op_skycity_folsys.connectionPlace.placeID
	WHERE r35755op_skycity_folsys.connectionPlace.userID = '" . $userID . "'

	ORDER BY timePosted DESC
	LIMIT " . $limit . "
	OFFSET " . $offset . "";
$results = $conn -> query($SQL);
if($results -> num_rows == 0){
    $conn -> close();
    exit("response-negative");
}

$globalMarkLink = '../../../../data/users/posts/global/post-marks/';
$globalCommentLink = '../../../../data/users/posts/global/post-comments/';
$localMarkLink = '../../../../data/users/posts/local/post-marks/';
$localCommentLink = '../../../../data/users/posts/local/post-comments/';
$output = "";
while($row = $results -> fetch_assoc()){
    /* Logic assumption: globalPostID, placeID, placeName, senderID, senderName, senderGender, timePosted are mandatory parameters always available in the model layer of a Skycity post*/
    $globalRow = array("globalPostID" => $row['globalPostID']);
    $configuration = json_decode($row['configuration'], true);

    $globalRow['placeID'] = $configuration['isUser'] == true ? $configuration['placeID'] : $row['senderID'];
    $SQL = "SELECT r35755op_skycity_folsys.place.name
            FROM r35755op_skycity_folsys.place
            WHERE r35755op_skycity_folsys.place.placeID = '" . $globalRow['placeID'] . "'
            LIMIT 1";
    $result = $conn -> query($SQL);
    if($result -> num_rows > 0){
    	$result = $result -> fetch_assoc();
    	$globalRow['placeName'] = $result['name'];
    }
    else{
    	$globalRow['placeName'] = "Skycity place";
    }

    /* Logic assumption: If the senderID == 1, the local platform know in the data model how to handle this case because the PHP returns always the placeID & placeName values. */
    if($configuration['isUser'] == true){
        $globalRow['senderID'] = $row['senderID'];
        $SQL = "SELECT CONCAT(r35755op_skycity_folsys.user.firstName, ' ', r35755op_skycity_folsys.user.lastName) AS name, r35755op_skycity_folsys.gender.value
	        FROM r35755op_skycity_folsys.user
	        INNER JOIN r35755op_skycity_folsys.gender
	        ON r35755op_skycity_folsys.user.genderID = r35755op_skycity_folsys.gender.genderID
	        WHERE r35755op_skycity_folsys.user.userID = '" . $globalRow['senderID'] . "'
	        LIMIT 1";
        $result = $conn -> query($SQL); if($result -> num_rows == 0) exit("gender".$connectionError); $result = $result -> fetch_assoc();
        $globalRow['senderName'] = unsecureString($result['name']);
        $globalRow['senderGender'] = $result['value'];
    }
    else{
        $globalRow['senderName'] = "";
        $globalRow['senderGender'] = 'neutral';
    }

    $globalRow['timePosted'] = $row['timePosted'];

    if($configuration['isTweet'] == false){
        $postID = $configuration['postID'];
        $SQL = "SELECT r35755op_skycity_local.place_".$globalRow['placeID']."_post.content, r35755op_skycity_local.place_".$globalRow['placeID']."_post.attachment
                FROM r35755op_skycity_local.place_".$globalRow['placeID']."_post
                WHERE r35755op_skycity_local.place_".$globalRow['placeID']."_post.postID = '" . $postID . "'
                LIMIT 1";
        $result = $conn -> query($SQL); if($result -> num_rows == 0) exit("place" . $connectionError); $result = $result -> fetch_assoc();
        $globalRow['content'] = unsecureString($result['content']);
        $globalRow['attachment'] = $result['attachment'];


	/* Get the trivial marks & comments data -- Ultra cases checked */
	if(!file_exists($localMarkLink . $globalRow['placeID'] . "-" . $postID)){
	        $readFile = fopen($localMarkLink . $globalRow['placeID'] . "-" . $postID, "r");
	        $markNumber = fgets($readFile);
	        $markNumber = filter_var($markNumber, FILTER_SANITIZE_NUMBER_INT);
	        $globalRow['marks'] = $markNumber;
	        $globalRow['isSelfMarked'] = strpos(fgets($readFile), "," . $userID . ",") !== false;
	        fclose($readFile);
        }
        else{
        	fopen($localMarkLink . $globalRow['placeID'] . "-" . $postID, "w");
        	$globalRow['marks'] = 0;
        	$globalRow['isSelfMarked'] = false;
        }
        
	if(!file_exists($localCommentLink . $globalRow['placeID'] . "-" . $postID)){
	        $readFile = fopen($localCommentLink . $globalRow['placeID'] . "-" . $postID, "r");
	        $commentNumber = fgets($readFile);
	        $commentNumber = filter_var($commentNumber, FILTER_SANITIZE_NUMBER_INT);
	        $globalRow['comments'] = $commentNumber;
	        fclose($readFile);
        }
	else{
		fopen($localCommentLink . $globalRow['placeID'] . "-" . $postID, "w");
		$globalRow['comments'] = 0;
	}
	
	
        /* Retrieve the taggers if there are any. */
        if(strpos($globalRow['attachment'],'tag') !== false){
            $globalRow['taggers'] = retrieveTaggers($globalRow['placeID'], $postID);
        }
        
        
        /* Retrieve the menu-item if there is one. */
        if(strpos($row['attachment'],'menu-item') !== false){
	    	$menuItemLink = "../../../../data/users/posts/local/post-menu-item/" . $placeID . "-" . $row['postID'];
	    	$readFile = fopen($menuItemLink, "r");
	    	$menuItemID = fgets($readFile);
	    	$globalRow['menuItemID'] = $menuItemID;
	    	// TODO
    	}

	/* Encapsulate the configuration dictionary and leave */
        $globalRow['configuration'] = $row['configuration'];
        $output[] = $globalRow;
    }
    else{
        /* The quite simple instructios for the tweet case, when configuration.isTweet = true */
        $globalRow['content'] = $configuration['content'];
        $globalRow['attachment'] = "";

	/* Get the trivial marks & comments data -- Ultra cases checked */
	if(!file_exists($globalMarkLink . $globalRow['globalPostID'])){
	        $readFile = fopen($globalMarkLink . $globalRow['globalPostID'], "r");
	        $markNumber = fgets($readFile);
	        $markNumber = filter_var($markNumber, FILTER_SANITIZE_NUMBER_INT);
	        $globalRow['marks'] = $markNumber;
	        $globalRow['isSelfMarked'] = strpos(fgets($readFile), "," . $userID . ",") !== false;
	        fclose($readFile);
        }
        else{
        	fopen($globalMarkLink . $globalRow['globalPostID'], "w");
        	$globalRow['marks'] = 0;
        	$globalRow['isSelfMarked'] = false;
        }
        
	if(!file_exists($globalCommentLink . $globalRow['globalPostID'])){
	        $readFile = fopen($globalCommentLink . $globalRow['globalPostID'], "r");
	        $commentNumber = fgets($readFile);
	        $commentNumber = filter_var($commentNumber, FILTER_SANITIZE_NUMBER_INT);
	        $globalRow['comments'] = $commentNumber;
	        fclose($readFile);
        }
	else{
		fopen($globalCommentLink . $globalRow['globalPostID'], "w");
		$globalRow['comments'] = 0;
	}

	/* Encapsulate the configuration dictionary and leave */
        $globalRow['configuration'] = $row['configuration'];
        $output[] = $globalRow;
    }
}
print(json_encode($output));


function retrieveTaggers($placeID, $postID){
    $link = "../../../../data/users/posts/local/post-tags/";
    $readFile = fopen($link . $placeID . "-" . $postID, "r");

    $output = "";
    while(!feof($readFile)) {
        $readLine = fgets($readFile);
        $strlen = strlen($readLine);
        $id = ""; $newReadLine = "";
        for($i = 0; $i <= $strlen; ++$i) {
            $char = substr($readLine, $i, 1 );
            if(!is_numeric($char)){
                $newReadLine = substr($readLine, $i + 1, $strlen - $i - 1);
                break;
            }
            $id .= $char;
        }
        $row['taggerID'] = $id;
        $row['name'] = unsecureString($newReadLine);
        $output[] = $row;
    }

    fclose($readFile);
    return json_encode($output);
}

$conn -> close();
?>