<?php
/**
 * Created by PhpStorm.
 * User: razvanpaul
 * Date: 09/01/16
 * Time: 12:49
 */

include '../../../../../../../../libs/skycity-functions.php';


$userID = $_POST['userID'];
$ID = $_POST['ID'];
$type = $_POST['type'];

$activitySearchPath = '/home/r35755opti/public_html/skycity/data/users/activity/search/all/' . $userID;
$limit = 16;

$content = file_get_contents($activitySearchPath);
if(empty($content)){
    $content = array();
}
else{
    $content = json_decode($content, true);
}

if(($key = array_search(array("ID" => $ID, "type" => $type), $content)) !== false){
	unset($content[$key]);
	$content[] = array("ID" => $ID, "type" => $type);
	$content = array_values($content);
}
else if(count($content) != $limit){
    $content[] = array("ID" => $ID, "type" => $type);
}
else{
    foreach($content as $key => $value) {
        if ($key == 0){
            continue;
        }
        $content[$key - 1] = $value;
    }
    $content[$limit - 1] = array("ID" => $ID, "type" => $type);
}

$file = fopen($activitySearchPath, "w");
fwrite($file, json_encode($content));
fclose($file);

echo 'response-ok';
?>