<?php
/**
 * Created by PhpStorm.
 * User: razvanpaul
 * Date: 09/01/16
 * Time: 12:30
 */

include '../../../../../../../../libs/skycity-functions.php';
$conn = globalAccess($folsys);

$userID = $_POST['userID'];
$activitySearchPath = '/home/r35755opti/public_html/skycity/data/users/activity/search/place/' . $userID;
if(!fopen($activitySearchPath, "r")){
	fopen($activitySearchPath, "w");
}

$content = file_get_contents($activitySearchPath);
if(empty($content)){
    exit('response-negative');
}

$content = json_decode($content, true);
$output = "";
for($i = count($content) - 1; $i >= 0; --$i){
    $current = $content[$i];

    $row['placeID'] = $current;
    $SQL = "SELECT name FROM place WHERE placeID = '" . $row['placeID'] . "' LIMIT 1";
    $result = $conn -> query($SQL);
    if($result -> num_rows > 0){
    	$result = $result -> fetch_assoc();
    	$row['name'] = $result['name'];
    }
    else{
   	$row['name'] = "Skycity user"; 
    }
    $output[] = $row;
}

print(json_encode($output));
?>