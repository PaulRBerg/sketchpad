<?php
/**
 * Created by PhpStorm.
 * User: razvanpaul
 * Date: 09/01/16
 * Time: 12:31
 */

include '../../../../../../../../libs/skycity-functions.php';
$conn = globalAccess($folsys);

$userID = $_POST['userID'];
$content = $_POST['content'];
$limit = $_POST['limit'];
$offset = $_POST['offset'];

$content = substr($content, 0, 196);
$SQL = "SELECT user.userID as ID,
		CONCAT(user.firstName, ' ', user.lastName) AS name,
        'U' AS type,
        (if((SELECT COUNT(connectionUser.connectionUserID)
				FROM connectionUser
				WHERE connectionUser.userID1 = " . $userID . "
				AND connectionUser.userID2 = ID) = 1, 10, 0)
		+

        if((SELECT IFNULL((SELECT userID
				FROM
					(
						SELECT connectionUser.userID2 AS userID
						FROM connectionUser
						WHERE connectionUser.userID1 = " . $userID . "
					) AS following
				INNER JOIN connectionUser
				ON following.userID = connectionUser.userID1
				WHERE connectionUser.userID2 = ID
                LIMIT 1), 0)) != 0, 1, 0)
        
        +
        
        if(CONCAT(user.firstName, ' ', user.lastName) LIKE '{$content}%', 1, 0)

	)AS relevance
	
        FROM user
        WHERE CONCAT(user.firstName, ' ', user.lastName) LIKE '%{$content}%'

        UNION

        SELECT place.placeID AS ID,
        place.name,
        'P' AS type,
        (if((SELECT COUNT(connectionPlace.connectionPlaceID)
				FROM connectionPlace
				WHERE connectionPlace.userID = " . $userID . "
				AND connectionPlace.placeID = ID) = 1, 5, 0)
	+

        if((SELECT IFNULL((SELECT place
				FROM
					(
						SELECT connectionUser.userID2 AS place
						FROM connectionUser
						WHERE connectionUser.userID1 = " . $userID . "
					) AS following
				INNER JOIN connectionPlace
				ON following.place = connectionPlace.userID
				WHERE connectionPlace.placeID = ID
                LIMIT 1), 0)) != 0, 1, 0)
	
	+
        
	if(name LIKE '{$content}%', 1, 0)

	)AS relevance

        FROM place
        WHERE name LIKE '%{$content}%'

        ORDER BY relevance DESC, name ASC
        LIMIT " . $limit . "
        OFFSET " . $offset . "";

$results = $conn -> query($SQL);
//var_dump($results);
if($results -> num_rows == 0){
    $conn -> close();
    exit("response-negative");
}

$output = "";
while($row = $results ->fetch_assoc()){
    if($row['type'] == 'U'){
        $row['userID'] = $row['ID'];
    }
    else if($row['type'] == 'P'){
        $row['placeID'] = $row['ID'];
    }
    unset($row['ID']);
    unset($row['type']);

    $output[] = $row;
}

print(json_encode($output));
$conn -> close();
?>