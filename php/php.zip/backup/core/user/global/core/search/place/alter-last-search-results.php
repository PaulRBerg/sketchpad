<?php
/**
 * Created by PhpStorm.
 * User: razvanpaul
 * Date: 09/01/16
 * Time: 12:49
 */

include '../../../../../../../../libs/skycity-functions.php';


$userID = $_POST['userID'];
$placeID = $_POST['placeID'];

$activitySearchPath = '/home/r35755opti/public_html/skycity/data/users/activity/search/place/' . $userID;
$limit = 16;

$content = file_get_contents($activitySearchPath);
if(empty($content)){
    $content = array();
}
else{
    $content = json_decode($content, true);
}

if(($key = array_search($placeID, $content)) !== false){
	unset($content[$key]);
	$content[] = $placeID;
	$content = array_values($content);
}
else if(count($content) != $limit){
    $content[] = $placeID;
}
else{
    foreach($content as $key => $value) {
        if ($key == 0){
            continue;
        }
        $content[$key - 1] = $value;
    }
    $content[$limit - 1] = $placeID;
}

$file = fopen($activitySearchPath, "w");
fwrite($file, json_encode($content));
fclose($file);

echo 'response-ok';
?>