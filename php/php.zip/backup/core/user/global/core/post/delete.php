<?php
/**
 * Created by PhpStorm.
 * User: razvanpaul
 * Date: 14/01/16
 * Time: 12:40
 */

include '../../../../../../../libs/skycity-functions.php';
$conn = globalAccess($postsys);

$userID = $_POST['userID'];
$globalPostID = (int) $_POST['globalPostID'];
$placeID = (int) $_POST['placeID'];

$SQL = "DELETE from postUser WHERE postUserID = " . $globalPostID . " ";
$conn -> query($SQL);

$markLink = "../../../../../data/users/posts/global/post-marks/" . $globalPostID;
$commentLink = "../../../../../data/users/posts/global/post-comments/" . $globalPostID;

if(file_exists($markLink))unlink($markLink);
if(file_exists($commentLink))unlink($commentLink);
belittleUserActivity($userID, $placeID, $globalPostID, "global");

echo 'response-ok';
$conn -> close();
?>