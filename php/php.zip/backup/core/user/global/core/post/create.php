<?php
/**
 * Created by PhpStorm.
 * User: razvanpaul
 * Date: 03/01/16
 * Time: 21:39
 */
include '../../../../../../../libs/skycity-functions.php';
$conn = globalAccess($postsys);

$senderID = $_POST['senderID'];
$placeID = (int) $_POST['placeID'];
$content = mysql_escape_mimic(secureString($_POST['content']));
$rendezvous = $_POST['rendezvous'];

$configuration = json_encode(["isTweet" => true, "isUser" => true, "placeID" => $placeID, "content" => $content, "rendezvous" => $rendezvous]);

$SQL = "INSERT INTO postUser(senderID, configuration)
        VALUES('" . $senderID . "', '" . $configuration . "')";
$conn -> query($SQL) or exit('response-negative');
$globalPostID = $conn -> insert_id;

$markFile = fopen("/home/r35755opti/public_html/skycity/data/users/posts/global/post-marks/" . $globalPostID, "w");
fwrite($markFile, "0\n");
fclose($markFile);

$commentFile = fopen("/home/r35755opti/public_html/skycity/data/users/posts/global/post-comments/" .  $globalPostID, "w");
fwrite($commentFile, "0");
fclose($commentFile);

enlargeUserActivity($senderID, $placeID, $globalPostID, "global");

echo $globalPostID;
$conn -> close();
?>