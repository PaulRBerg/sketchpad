<?php
/**
 * Created by PhpStorm.
 * User: razvanpaul
 * Date: 14/01/16
 * Time: 12:40
 */

include '../../../../../../../libs/skycity-functions.php';
$conn = globalAccess($postsys);

$globalPostID = $_POST['globalPostID'];
$placeID = (int) $_POST['placeID'];
$content = mysql_escape_mimic(secureString($_POST['content']));
$rendezvous = $_POST['rendezvous'];

$configuration = json_encode(array("isTweet" => true, "isUser" => true, "placeID" => $placeID, "content" => $content, "rendezvous" => $rendezvous));
$SQL = "UPDATE postUser SET configuration = '" . $configuration . "' WHERE postGlobalID = " . $globalPostID . "";

if($conn -> query($SQL)){
    echo 'response-ok';
}
else{
    echo 'response-negative';
}

$conn -> close();
?>