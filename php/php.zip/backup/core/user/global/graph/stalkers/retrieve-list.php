<?php
/**
 * Created by PhpStorm.
 * User: razvanpaul
 * Date: 01/01/16
 * Time: 15:14
 */

include '../../../../../../../libs/skycity-functions.php';
$conn = globalAccess($folsys);
$connectionError = "CONNECTION_ERROR";

$userID = $_POST['userID'];
$limit = $_POST['limit'];
$offset = $_POST['offset'];

$SQL = "SELECT connectionUser.connectionUserID AS connectionID, connectionUser.userID1 AS stalkerID, CONCAT(user.firstName, ' ', user.lastName) AS name
        FROM connectionUser
        INNER JOIN user
        ON connectionUser.userID1 = user.userID
        WHERE connectionUser.userID2 = '" . $userID . "'
        LIMIT " . $limit . "
        OFFSET " . $offset . "";
$results = $conn -> query($SQL);

if($results -> num_rows > 0){
    $output = "";
    while($row = $results -> fetch_assoc()){
        $row['selected'] = true;
        $output[] = $row;
    }
    print(json_encode($output));
}
else{
    echo 'response-negative';
}

$conn -> close();
?>