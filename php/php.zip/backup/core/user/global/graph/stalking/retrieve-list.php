<?php
/**
 * Created by PhpStorm.
 * User: razvanpaul
 * Date: 31/12/15
 * Time: 00:18
 */
include '../../../../../../../libs/skycity-functions.php';
$conn = globalAccess($folsys);

$userID = $_POST['userID'];
$limit = $_POST['limit'];
$offset = $_POST['offset'];

$SQL = "SELECT connectionUser.connectionUserID AS connectionID, connectionUser.userID2 AS stalkingID, CONCAT(user.firstName, ' ', user.lastName) AS name
        FROM connectionUser
        INNER JOIN user
        ON connectionUser.userID2 = user.userID
        WHERE connectionUser.userID1 = '" . $userID . "'
        LIMIT " . $limit . "
        OFFSET " . $offset . "";
$results = $conn -> query($SQL);

if($results -> num_rows > 0){
        $output = "";
        while($row = $results -> fetch_assoc()){
            $row['selected'] = true;
            $output[] = $row;
        }
        print(json_encode($output));
}
else{
    echo 'response-negative';
}

$conn -> close();
?>