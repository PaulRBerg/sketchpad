<?php
/**
 * Created by PhpStorm.
 * User: razvanpaul
 * Date: 31/12/15
 * Time: 19:13
 */

/*
 * Logic assumption: $nouveau == 1 is for creation, 2 is for removal
 * Logic assumption 2 : $type == 1 is for user, 2 is for place
 */

include '../../../../../../libs/skycity-functions.php';
$conn = globalAccess($folsys);
define("create",  1); define("user", 1);
define("remove", 2); define("place", 2);

$userID = $_POST['userID'];
$destinationID = $_POST['destinationID'];
$nouveau = $_POST['nouveau'];
$type = $_POST['type'];

if($nouveau == create){
    if($type == user){
        $SQL = "INSERT INTO connectionUser(userID1, userID2)
                VALUES ('" . $userID . "', '" . $destinationID . "')";
        if($conn -> query($SQL)){
    		if(strpos($SQL,"INSERT") !== false) {
    			echo $conn -> insert_id;
		}
        	else{
        		echo 'response-ok';
      		}
    	}
    	else{
        	echo 'response-negative';
    	}
    }
    else if($type == place){
        $SQL = "INSERT INTO connectionPlace(userID, placeID)
                VALUES('" . $userID . "', '" . $destinationID . "')";
        if($conn -> query($SQL)){
    		if(strpos($SQL,"INSERT") !== false) {
    			echo $conn -> insert_id;
		}
        	else{
        		echo 'response-ok';
      		}
    	}
    	else{
        	echo 'response-negative';
    	}
    }
}
else if($nouveau == remove){
    $connectionID = $_POST['connectionID'];
    if($type == user){
        $SQL = "DELETE FROM connectionUser
                WHERE connectionUser.connectionUserID = '" . $connectionID . "'";
        if($conn -> query($SQL)){
    		if(strpos($SQL,"INSERT") !== false) {
    			echo $conn -> insert_id;
		}
        	else{
        		echo 'response-ok';
      		}
    	}
    	else{
        	echo 'response-negative';
    	}
    }
    else if($type == place){
        $SQL = "DELETE FROM connectionPlace
                WHERE connectionPlace.connectionPlaceID = '" . $connectionID . "'";
        if($conn -> query($SQL)){
    		if(strpos($SQL,"INSERT") !== false) {
    			echo $conn -> insert_id;
		}
        	else{
        		echo 'response-ok';
      		}
    	}
    	else{
        	echo 'response-negative';
    	}
    }
}

$conn -> close();
?>