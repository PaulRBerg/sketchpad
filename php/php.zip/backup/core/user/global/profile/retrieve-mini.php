<?php

include '../../../../../../skycity-functions.php';
$conn = globalAccess($folsys);

$userID = $_POST['userID'];
$SQL = "Select CONCAT(user.firstName, ' ', user.lastName) AS name, gender.value as gender
	FROM user
	INNER JOIN gender
	ON user.genderID = gender.genderID
	WHERE userID = " . $userID . " LIMIT 1";
$results = $conn -> query($SQL);

if($results -> num_rows > 0){
	$row = $results -> fetch_assoc();
	$row['name'] = unsecureString($row['name']);
	if(empty($row['gender'])){
    			$row['gender'] = "";
    	}
    		
	echo json_encode($row);
}
else{
	echo 'response-negative';
}

$conn -> close();

?>