<?php
/**
 * Created by PhpStorm.
 * User: razvanpaul
 * Date: 02/01/16
 * Time: 16:56
 */

include '../../../../../../libs/skycity-functions.php';
$conn = globalAccess($folsys);

$selfID = $_POST['selfID'];
$userID = $_POST['userID'];
$sql = "SELECT CONCAT(user.firstName, ' ', user.lastName) AS name, user.email, user.city, user.birthday, user.phone, user.social, user.description, gender.value AS gender
        FROM user
        INNER JOIN gender
        ON user.genderID = gender.genderID
        WHERE userID = '" . $userID . "'
        LIMIT 1";
$result = $conn -> query($sql);

if($result -> num_rows > 0){
	$output = "";
    	while($row = $result -> fetch_assoc()){
	        $row['name'] = unsecureString($row['name']);
	        $row['city'] =  unsecureString($row['city']);
	        $row['phone'] =  unsecureString($row['phone']);
	        $row['description'] = unsecureString($row['description']);
	        $row['social'] = convertSocial($row['social']);
	        
	        if(!empty($selfID)){
	        	$SQL = "SELECT connectionUserID AS connectionID FROM connectionUser WHERE userID1 = '" . $selfID . "' AND userID2 = '" . $userID . "' LIMIT 1";
	        	$following = $conn -> query($SQL);
	        	if($following -> num_rows == 0){
	        		$row['following'] = false;
	        	}
	        	else{
	        		$row['following'] = true;
	        		$row['connectionID'] = $following -> fetch_assoc()['connectionID'];
	        	}
	        }
	        $output[] = $row;
	    }
	print(json_encode($output));
}
else{
   	echo 'response-negative';
}


function convertSocial($array){
	if(!is_array($array)){
		return $array;
	}
   	$array = json_decode($array, true);
    	$clean = array();
   	 
	foreach($array as $key => $value){
        	$clean[$key] = unsecureString($value);
  	}
    	return json_encode($clean);
}

$conn -> close();
?>