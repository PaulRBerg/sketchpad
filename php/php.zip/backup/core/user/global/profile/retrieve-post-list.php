<?php
/**
 * Created by PhpStorm.
 * User: razvanpaul
 * Date: 02/01/16
 * Time: 16:57
 */


include '../../../../../../libs/skycity-functions.php';
$conn = globalAccess($universalsys);
$connectionError = "CONNECTION_ERROR";

$userID = $_POST['userID'];
$limit = $_POST['limit'];
$offset = $_POST['offset'];

$activityLink = '../../../../data/users/activity/' . $userID;
fopen($activityLink, 'r') or exit("response-negative");
$content = json_decode(file_get_contents($activityLink), true);

$newContent = array();
foreach($content as $element){
    if(array_key_exists("globalPostID", $element)){
        $newContent[] = $element;
    }
}
$content = $newContent;
if(count($content) == 0){
	$conn -> close();
	exit('response-negative');	
}

//var_dump($content);
$globalMarkLink = '../../../../data/users/posts/global/post-marks/';
$globalCommentLink = '../../../../data/users/posts/global/post-comments/';
$localMarkLink = '../../../../data/users/posts/local/post-marks/';
$localCommentLink = '../../../../data/users/posts/local/post-comments/';
$output = "";
for($i = count($content) - $offset - 1; $i >= (count($content) - $offset - $limit) && $i >= 0; --$i){
    $current = $content[$i];
    $globalRow = array("globalPostID" => $current['globalPostID']);

    $SQL = "SELECT r35755op_skycity_postsys.postUser.senderID,
	    r35755op_skycity_postsys.postUser.configuration,
	    r35755op_skycity_postsys.postUser.timePosted
        FROM r35755op_skycity_postsys.postUser
        WHERE r35755op_skycity_postsys.postUser.postUserID = '" . $globalRow['globalPostID'] . "'
        LIMIT 1";
    $row = $conn -> query($SQL); if($row -> num_rows == 0) exit("postUser".$connectionError); $row = $row -> fetch_assoc();
    $configuration = json_decode($row['configuration'], true);

    $globalRow['placeID'] = $configuration['placeID'];
    $SQL = "SELECT r35755op_skycity_folsys.place.name
            FROM r35755op_skycity_folsys.place
            WHERE r35755op_skycity_folsys.place.placeID = '" . $globalRow['placeID'] . "'
            LIMIT 1";
    $result = $conn -> query($SQL); if($result -> num_rows == 0) exit("place".$connectionError); $result = $result -> fetch_assoc();
    $globalRow['placeName'] = $result['name'];

    $globalRow['senderID'] = $row['senderID'];
    if($globalRow['senderID'] != $userID){
        $SQL = "SELECT CONCAT(r35755op_skycity_folsys.user.firstName, ' ', r35755op_skycity_folsys.user.lastName) AS name, r35755op_skycity_folsys.gender.value
	        FROM r35755op_skycity_folsys.user
	        INNER JOIN r35755op_skycity_folsys.gender
	        ON r35755op_skycity_folsys.user.genderID = r35755op_skycity_folsys.gender.genderID
	        WHERE r35755op_skycity_folsys.user.userID = '" . $globalRow['senderID'] . "'
	        LIMIT 1";
        $result = $conn -> query($SQL); if($result -> num_rows == 0) exit("gender".$connectionError); $result = $result -> fetch_assoc();
        $globalRow['senderName'] = unsecureString($result['name']);
        $globalRow['senderGender'] = $result['value'];
    }
    $globalRow['timePosted'] = $row['timePosted'];

    if($configuration['isTweet'] == false){
        $postID = $configuration['postID'];
        $SQL = "SELECT r35755op_skycity_local.place_".$globalRow['placeID']."_post.content, r35755op_skycity_local.place_".$globalRow['placeID']."_post.attachment
                FROM r35755op_skycity_local.place_".$globalRow['placeID']."_post
                WHERE r35755op_skycity_local.place_".$globalRow['placeID']."_post.postID = '" . $postID . "'
                LIMIT 1";
        $result = $conn -> query($SQL); if($result -> num_rows == 0) exit("place" . $connectionError); $result = $result -> fetch_assoc();
        $globalRow['content'] = unsecureString($result['content']);
        $globalRow['attachment'] = $result['attachment'];

        $readFile = fopen($localMarkLink . $globalRow['placeID'] . "-" . $postID, "r");
        $markNumber = fgets($readFile);
        $markNumber = filter_var($markNumber, FILTER_SANITIZE_NUMBER_INT);
        $globalRow['marks'] = $markNumber;
        $globalRow['isSelfMarked'] = strpos(fgets($readFile), "," . $userID . ",") !== false;

        $readFile = fopen($localCommentLink . $globalRow['placeID'] . "-" . $postID, "r");
        $commentNumber = fgets($readFile);
        $commentNumber = filter_var($commentNumber, FILTER_SANITIZE_NUMBER_INT);
        $globalRow['comments'] = $commentNumber;

        if(strpos($globalRow['attachment'],'tag') !== false) {
            $globalRow['taggers'] = retrieveTaggers($globalRow['placeID'], $postID);
        }

        $globalRow['configuration'] = $row['configuration'];
        $output[] = $globalRow;
        fclose($readFile);
    }
    else{
        $globalRow['content'] = unsecureString($configuration['content']);
        $globalRow['attachment'] = "";

        $readFile = fopen($globalMarkLink . $globalRow['globalPostID'], "r");
        $markNumber = fgets($readFile);
        $markNumber = filter_var($markNumber, FILTER_SANITIZE_NUMBER_INT);
        $globalRow['marks'] = $markNumber;
        $globalRow['isSelfMarked'] = strpos(fgets($readFile), "," . $userID . ",") !== false;

        $readFile = fopen($globalCommentLink . $globalRow['globalPostID'], "r");
        $commentNumber = fgets($readFile);
        $commentNumber = filter_var($commentNumber, FILTER_SANITIZE_NUMBER_INT);
        $globalRow['comments'] = $commentNumber;

        $globalRow['configuration'] = $row['configuration'];
        $output[] = $globalRow;
        fclose($readFile);
    }
}
print(json_encode($output));


function retrieveTaggers($placeID, $postID){
    $link = "../../../../data/users/posts/local/post-tags/";
    $readFile = fopen($link . $placeID . "-" . $postID, "r");

    $output = "";
    while(!feof($readFile)) {
        $readLine = fgets($readFile);
        $strlen = strlen($readLine);
        $id = ""; $newReadLine = "";
        for($i = 0; $i <= $strlen; ++$i) {
            $char = substr($readLine, $i, 1 );
            if(!is_numeric($char)){
                $newReadLine = substr($readLine, $i + 1, $strlen - $i - 1);
                break;
            }
            $id .= $char;
        }
        $row['taggerID'] = $id;
        $row['name'] = unsecureString($newReadLine);
        $output[] = $row;
    }

    fclose($readFile);
    return json_encode($output);
}

$conn -> close();
?>