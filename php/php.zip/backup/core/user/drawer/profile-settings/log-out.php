<?php

include '../../../../../../libs/skycity-functions.php';
$conn = globalAccess($universalsys);

$userID = $_POST['userID'];
$placeID = $_POST['placeID'];
$deviceID = $_POST['deviceID'];

$SQL = "DELETE FROM r35755op_skycity_folsys.device WHERE r35755op_skycity_folsys.device.deviceID = '" . $deviceID . "'";
$SQL2 = "DELETE FROM r35755op_skycity_local.place_" . $placeID . "_connection WHERE r35755op_skycity_local.place_".$placeID."_connection.userID = '" . $userID . "' ";
$conn -> query($SQL2);

if($conn -> query($SQL)){
	echo 'response-ok';
}
else{
	echo 'response-negative';
}
$conn -> close();
?>