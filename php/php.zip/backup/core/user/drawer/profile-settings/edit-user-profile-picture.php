<?php

include '../../../../../../libs/ImageResize.php';
use \Eventviva\ImageResize;

function editProfilePictureAndGetPath($filePath){
	
	$newFilePath = '../../../../Data/Users/Pictures/Profile/';
	$fileName = $_POST['fileName'];
	$newFilePath = $newFilePath . $fileName;
	
	//unlink($newFilePath); // DELETE THE OLD PICTURE
	//rename($filePath, $newFilePath); // ASIGN THE NEW PATH TO THE NEW PICTURE
	
	return $newFilePath;
}

function renameAndMoveToTrash($newFilePath, $fileName){
	$trashPath = '../../Data/Trash/';
	$trashPath = $trashPath . $fileName;
	rename($newFilePath, $trashPath);
	unlink($trashPath);
}

function editThumbnail($whichOne, $filePath){
	$fileName = $_POST['fileName'];
		
	$newFilePath = "";
	$width = $height = 0;
	
	switch($whichOne){
		case 1 :
			$newFilePath = '../../../../Data/Users/Pictures/Thumbnail1/';
			renameAndMoveToTrash($newFilePath . $fileName, $fileName);
			$width = $height = 320;
			break;
		case 2:
			$newFilePath = '../../../../Data/Users/Pictures/Thumbnail2/';
			renameAndMoveToTrash($newFilePath . $fileName, $fileName);
			$width = $height = 160;
			break;
		case 3:
			$newFilePath = '../../../../Data/Users/Pictures/Thumbnail3/';
			renameAndMoveToTrash($newFilePath . $fileName, $fileName);
			$width = $height = 80;
			break;
		default:
			break;
	}
	$newFilePath = $newFilePath . $fileName;
	
	$resizer = new ImageResize($filePath);
	$resizer -> resize($width, $height);
	$resizer -> save($newFilePath, null, 100);
}

$filePath = '../../../../Data/Users/Pictures/Profile/';
$fileSuffix = $_POST['fileName'];
$filePath = $filePath . $fileSuffix;

if(file_exists($filePath)){
	unlink($filePath);
}

if(move_uploaded_file($_FILES['imageFile']['tmp_name'], $filePath)) {
	
	/*
	echo '<pre>' . var_dump($var) . '</pre>';
	echo '<pre>' . var_dump($filePath) . '</pre>';
	*/
	
	for($i = 1; $i <= 3; $i++){
		editThumbnail($i, $filePath);
	}
	
	//echo 'PROFILE_UPDATED_SUCCESSFULLY';
} 
else{
	echo 'UPLOAD_FAIL_PHP_FILE';
}
?>