<?php

include '../../../../../../SkycityFunctions.php';
$conn = globalAccess();

$PlaceID = $_POST['PlaceID'];
$UserID = $_POST['UserID'];
$Visible = $_POST['Visible'];


$sql = "UPDATE Place_" . $PlaceID ."_Connections SET Visible = '" . $Visible . "' WHERE UserID = '" . $UserID . "' "; 
$conn -> query($sql);

echo 'STATE_CHANGED_SUCCESSFULLY';

$conn -> close();
?>