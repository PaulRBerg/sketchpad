<?php

include '../../../../../../SkycityFunctions.php';
$conn = globalAccess();

$UserID = $_POST['UserID'];
$Name = $_POST['Name'];
$City = $_POST['City'];
$Phone= $_POST['Phone'];
$Birthday = $_POST['Birthday'];
$Facebook = $_POST['Facebook'];
$Description = $_POST['Description'];

$sql = "SELECT Name FROM Users WHERE ID = " . $UserID . " LIMIT 1";
$results = $conn -> query($sql);
if($results -> num_rows > 0){
	$row = $results->fetch_assoc();
	
	$Name = secureString($Name);
	if($row['Name'] !== $Name){
		$sql = "SELECT ID FROM Places";
		$results = $conn -> query($sql);
			while($row = $results->fetch_assoc()){
				$PlaceID = $row['ID'];
				$SQL = "UPDATE Place_" . $PlaceID . "_Posts SET SenderName = '" . $Name . "' WHERE SenderID = " . $UserID . "";
				$conn -> query($SQL);
		}
	}
	
	$City = secureString($City);
	$Phone = secureString($Phone);
	$Birthday = secureString($Birthday);
	$Facebook = secureString($Facebook);
	$Description = secureString($Description);
	$SQL = "UPDATE Users SET Name = '" . $Name . "', City = '" . $City . "', Phone = '" . $Phone . "', Birthday = '" . $Birthday . "', Facebook = '" . $Facebook . "', Description = '" . $Description . "' WHERE ID = '" . $UserID . "' ";
	$conn -> query($SQL);

	echo 'PROFILE_UPDATED_SUCCESSFULLY';
}

$conn -> close();
?>