<?php

include '../../../../../../libs/skycity-functions.php';
$conn = globalAccess($folsys);

$userID = $_POST['userID'];
$location = $_POST['location'];

$SQL = "SELECT place.placeID, place.name, place.profile, place.configuration,
		IFNULL(connectionPlace.connectionPlaceID,0) as connectionID,
        if(connectionPlace.connectionPlaceID > 0, 1, 0) as following
        FROM place
        LEFT OUTER JOIN connectionPlace
        ON connectionPlace.userID = " . $userID . " AND connectionPlace.placeID = place.placeID
        WHERE city = '" . $location . "' ";
$results = $conn -> query($SQL);

if($results -> num_rows > 0){
	while($row = $results -> fetch_assoc()){
		$output[] = $row;
	}
	print(json_encode($output));
}
else{
	echo 'response-negative';
}

$conn -> close();
?>