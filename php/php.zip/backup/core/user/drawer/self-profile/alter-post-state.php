<?php

include '../../../../../../libs/skycity-functions.php';
$conn = globalAccess($postsys);

$userID = $_POST['userID'];
$placeID = (int)$_POST['placeID'];
$postID = (int)$_POST['postID'];
$globalPostID = $_POST['globalPostID'];

if(empty($globalPostID)){
	$timePosted = $_POST['timePosted'];
	$configuration = json_encode(["isTweet"=>false,"isUser"=>true,"placeID"=>$placeID,"postID"=>$postID]);
	$SQL = "INSERT INTO postUser(senderID, configuration, timePosted) VALUES('" . $userID . "', '" . $configuration . "', '" . $_POST['timePosted'] . "')";
	if($conn -> query($SQL)){
		$globalPostID = (int) $conn -> insert_id;
		alterUserActivity($userID, $placeID, $postID, $globalPostID, "global");
		$row = array("isUser" => true, "isGlobal" => true, "isTweet" => false, "placeID" => $placeID, "postID" => $postID, "globalPostID" => $globalPostID);
		echo json_encode($row);
	}
	else{
		echo 'response-negative';
	}
}
else{
	$SQL = "DELETE FROM postUser WHERE postUserID = '" . $globalPostID . "' ";
	if($conn -> query($SQL)){
		alterUserActivity($userID, $placeID, $postID, $globalPostID, "local");
		echo 'response-ok';
	}
	else{
		echo 'response-negative';
	}
}

$conn -> close();
?>