<?php
/**
 * Created by PhpStorm.
 * User: razvanpaul
 * Date: 02/01/16
 * Time: 18:47
 */

include '../../../../../../libs/skycity-functions.php';
$conn = globalAccess($postsys);
$connectionError = "CONNECTION_ERROR";

$userID = $_POST['userID'];
$limit = $_POST['limit'];
$offset = $_POST['offset'];

$activityLink = '../../../../data/users/activity/' . $userID;
fopen($activityLink, 'r') or exit("response-negative");
$content = json_decode(file_get_contents($activityLink), true);

$globalMarkLink = '../../../../data/users/posts/global/post-marks/';
$globalCommentLink = '../../../../data/users/posts/global/post-comments/';
$localMarkLink = '../../../../data/users/posts/local/post-marks/';
$localCommentLink = '../../../../data/users/posts/local/post-comments/';

$conn = globalAccess($universalsys);
$output = "";
for($i = count($content) - $offset - 1; $i >= (count($content) - $offset - $limit) && $i >= 0; --$i){
    $row = array();
    $current = $content[$i];
    //var_dump($current);
    
    $row['placeID'] = $current['placeID'];
    $SQL = "SELECT r35755op_skycity_folsys.place.name
            FROM r35755op_skycity_folsys.place
            WHERE r35755op_skycity_folsys.place.placeID = '" . $row['placeID'] . "'
            LIMIT 1";
    $result = $conn -> query($SQL); if($result -> num_rows == 0) exit($connectionError); $result = $result -> fetch_assoc();
    $row['placeName'] = $result['name'];

    if(array_key_exists("globalPostID", $current)){
        $globalPostID = $current['globalPostID'];
        //var_dump($globalPostID);
        $SQL = "SELECT r35755op_skycity_postsys.postUser.senderID,
            	r35755op_skycity_postsys.postUser.configuration,
	   	r35755op_skycity_postsys.postUser.timePosted
        FROM r35755op_skycity_postsys.postUser
        WHERE r35755op_skycity_postsys.postUser.postUserID = " . $globalPostID . "
        LIMIT 1";
        $post = $conn -> query($SQL); if($post -> num_rows == 0) exit("postUser".$connectionError); $post = $post -> fetch_assoc();

	if($post['senderID'] != $userID){
		//retrieveUser($conn, $row, $post['senderID']);
		$SQL = "SELECT CONCAT(r35755op_skycity_folsys.user.firstName, ' ', r35755op_skycity_folsys.user.lastName) AS name, r35755op_skycity_folsys.gender.value
	        FROM r35755op_skycity_folsys.user
	        INNER JOIN r35755op_skycity_folsys.gender
	        ON r35755op_skycity_folsys.user.genderID = r35755op_skycity_folsys.gender.genderID
	        WHERE r35755op_skycity_folsys.user.userID = '" . $post['senderID'] . "'
	        LIMIT 1";
		$user = $conn -> query($SQL); if($user -> num_rows == 0) exit("genderCONNECTION_ERROR"); $user = $user -> fetch_assoc();
    		$row['senderID'] = $post['senderID'];
    		$row['senderName'] = unsecureString($user['name']);
    		$row['senderGender'] = $user['value'];
	}
	else{
		$row['senderID'] = $userID;
	}
	
        $row['timePosted'] = $post['timePosted'];
        $configuration = json_decode($post['configuration'], true);
        if($configuration['isTweet'] == false){
            $row['postID'] = $globalPostID;
            $postID = $configuration['postID'];
            $SQL = "SELECT r35755op_skycity_local.place_".$row['placeID']."_post.content, r35755op_skycity_local.place_".$row['placeID']."_post.attachment
                FROM r35755op_skycity_local.place_".$row['placeID']."_post
                WHERE r35755op_skycity_local.place_".$row['placeID']."_post.postID = '" . $postID . "'
                LIMIT 1";
            $result = $conn -> query($SQL); if($result -> num_rows == 0) exit("place" . $connectionError); $result = $result -> fetch_assoc();
            $row['content'] = unsecureString($result['content']);
            $row['attachment'] = $result['attachment'];

            $readFile = fopen($localMarkLink . $row['placeID'] . "-" . $postID, "r");
            $markNumber = fgets($readFile);
            $markNumber = filter_var($markNumber, FILTER_SANITIZE_NUMBER_INT);
            $row['marks'] = $markNumber;
            $row['isSelfMarked'] = strpos(fgets($readFile), "," . $userID . ",") !== false;

            $readFile = fopen($localCommentLink . $row['placeID'] . "-" . $postID, "r");
            $commentNumber = fgets($readFile);
            $commentNumber = filter_var($commentNumber, FILTER_SANITIZE_NUMBER_INT);
            $row['comments'] = $commentNumber;

            if(strpos($row['attachment'],'tag') !== false) {
                $row['taggers'] = retrieveTaggers($row['placeID'], $postID);
            }

            $configuration['isGlobal'] = true;
            $row['configuration'] = json_encode($configuration);
            $output[] = $row;
            fclose($readFile);
        }
        else{
            $row['postID'] = $globalPostID;
            $row['content'] = unsecureString($configuration['content']);
            $row['attachment'] = "";

            $readFile = fopen($globalMarkLink . $globalPostID, "r");
            $markNumber = fgets($readFile);
            $markNumber = filter_var($markNumber, FILTER_SANITIZE_NUMBER_INT);
            $row['marks'] = $markNumber;
            $row['isSelfMarked'] = strpos(fgets($readFile), "," . $userID . ",") !== false;

            $readFile = fopen($globalCommentLink . $globalPostID, "r");
            $commentNumber = fgets($readFile);
            $commentNumber = filter_var($commentNumber, FILTER_SANITIZE_NUMBER_INT);
            $row['comments'] = $commentNumber;

            $configuration['isGlobal'] = true;
            $row['configuration'] = json_encode($configuration);
            $output[] = $row;
            fclose($readFile);
        }
    }
    else{
        $row['postID'] = $current['postID'];
        $SQL = "SELECT r35755op_skycity_local.place_".$row['placeID']."_post.senderID,
         r35755op_skycity_local.place_".$row['placeID']."_post.content,
         r35755op_skycity_local.place_".$row['placeID']."_post.attachment,
         r35755op_skycity_local.place_".$row['placeID']."_post.timePosted
                FROM r35755op_skycity_local.place_".$row['placeID']."_post
                WHERE r35755op_skycity_local.place_".$row['placeID']."_post.postID = '" . $row['postID'] . "'
                LIMIT 1";
        $post = $conn -> query($SQL); if($post -> num_rows == 0) exit("place" . $connectionError); $post = $post -> fetch_assoc();
        
        if($post['senderID'] != $userID){
		$SQL = "SELECT CONCAT(r35755op_skycity_folsys.user.firstName, ' ', r35755op_skycity_folsys.user.lastName) AS name, r35755op_skycity_folsys.gender.value
	        FROM r35755op_skycity_folsys.user
	        INNER JOIN r35755op_skycity_folsys.gender
	        ON r35755op_skycity_folsys.user.genderID = r35755op_skycity_folsys.gender.genderID
	        WHERE r35755op_skycity_folsys.user.userID = '" . $post['senderID'] . "'
	        LIMIT 1";
		$user = $conn -> query($SQL); if($user -> num_rows == 0) exit("genderCONNECTION_ERROR"); $user = $user -> fetch_assoc();
    		$row['senderID'] = $post['senderID'];
    		$row['senderName'] = unsecureString($user['name']);
    		$row['senderGender'] = $user['value'];
	}
	else{
		$row['senderID'] = $userID;
	}
	
        $row['content'] = unsecureString($post['content']);
        $row['attachment'] = $post['attachment'];
        $row['timePosted'] = $post['timePosted'];

        $readFile = fopen($localMarkLink . $row['placeID'] . "-" . $row['postID'], "r");
        $markNumber = fgets($readFile);
        $markNumber = filter_var($markNumber, FILTER_SANITIZE_NUMBER_INT);
        $row['marks'] = $markNumber;
        $row['isSelfMarked'] = strpos(fgets($readFile), "," . $userID . ",") !== false;

        $readFile = fopen($localCommentLink . $row['placeID'] . "-" . $row['postID'], "r");
        $commentNumber = fgets($readFile);
        $commentNumber = filter_var($commentNumber, FILTER_SANITIZE_NUMBER_INT);
        $row['comments'] = $commentNumber;

        if(strpos($row['attachment'],'tag') !== false) {
            $row['taggers'] = retrieveTaggers($row['placeID'], $row['postID']);
        }

        $configuration = json_encode(array("isUser" => true, "isGlobal" => false));
        $row['configuration'] = $configuration;
        $output[] = $row;
        fclose($readFile);
    }
}
print(json_encode($output));

function retrieveTaggers($placeID, $postID){
    $link = "../../../../data/users/posts/local/post-tags/";
    $readFile = fopen($link . $placeID . "-" . $postID, "r");

    $output = "";
    while(!feof($readFile)) {
        $readLine = fgets($readFile);
        $strlen = strlen($readLine);
        $id = ""; $newReadLine = "";
        for($i = 0; $i <= $strlen; ++$i) {
            $char = substr($readLine, $i, 1 );
            if(!is_numeric($char)){
                $newReadLine = substr($readLine, $i + 1, $strlen - $i - 1);
                break;
            }
            $id .= $char;
        }
        $row['taggerID'] = $id;
        $row['name'] = unsecureString($newReadLine);
        $output[] = $row;
    }

    fclose($readFile);
    return json_encode($output);
}

$conn -> close();
?>