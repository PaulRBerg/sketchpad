<?php

include '../../../../../../libs/skycity-functions.php';
include '../../../../../../libs/image-resize.php';
use \Eventviva\ImageResize;
$conn = globalAccess($folsys);

$userID = mysql_escape_mimic(secureString($_POST['userID']));
$firstName = mysql_escape_mimic(secureString($_POST['firstName']));
$lastName = mysql_escape_mimic(secureString($_POST['lastName']));
$city = mysql_escape_mimic(secureString($_POST['city']));
$phone = mysql_escape_mimic(secureString($_POST['phone']));
$birthday = mysql_escape_mimic(secureString($_POST['birthday']));
$social = mysql_escape_mimic(secureString($_POST['social']));
$description = mysql_escape_mimic(secureString($_POST['description']));

$SQL = "SELECT CONCAT(firstName, ' ', lastName) as name FROM user WHERE userID = " . $userID . " LIMIT 1";
$result = $conn -> query($SQL);
if($result -> num_rows > 0){
	$result = $result -> fetch_assoc();
	
	/* TODO
	$name = secureString($firstName . ' ' . $lastName);
	if($result['name'] !== $name){
		$sql = "SELECT placeID FROM place";
		$results = $conn -> query($sql);
			while($row = $results->fetch_assoc()){
				$PlaceID = $row['ID'];
				$SQL = "UPDATE Place_" . $PlaceID . "_Posts SET SenderName = '" . $Name . "' WHERE SenderID = " . $UserID . "";
				$conn -> query($SQL);
		}
	}*/
	
	$SQL = "UPDATE user SET firstName = '" . $firstName . "', lastName = '" . $lastName . "', city = '" . $city . "', phone = '" . $phone . "', birthday = '" . $birthday . "', social = '" . $social . "', description = '" . $description . "' WHERE userID = '" . $userID . "' ";
	$conn -> query($SQL);
	
	$fileSuffix = $_POST['fileName'];
	if($fileSuffix == "no-picture" || empty($fileSuffix)){
		exit('response-ok');
	}
	
	$filePath = '../../../../data/users/pictures/profile/' . $fileSuffix;	
	if(file_exists($filePath)){
		unlink($filePath);
	}
	
	if(move_uploaded_file($_FILES['imageFile']['tmp_name'], $filePath)) {
		for($i = 1; $i <= 3; $i++){
			editThumbnail($i, $filePath);
		}
		echo 'response-ok';
	} 
	else{
		echo 'response-negative';
	}	
}
else{
	echo 'response-negative';
}


function renameAndMoveToTrash($newFilePath, $fileName){
	$trashPath = '../../../../data/trash/';
	$trashPath = $trashPath . $fileName;
	rename($newFilePath, $trashPath);
	unlink($trashPath);
}

function editThumbnail($whichOne, $filePath){
	$fileName = $_POST['fileName'];
	$newFilePath = "";
	$width = $height = 0;
	
	switch($whichOne){
		case 1 :
			$newFilePath = '../../../../data/users/pictures/thumbnail1/';
			renameAndMoveToTrash($newFilePath . $fileName, $fileName);
			$width = $height = 320;
			break;
		case 2:
			$newFilePath = '../../../../data/users/pictures/thumbnail2/';
			renameAndMoveToTrash($newFilePath . $fileName, $fileName);
			$width = $height = 160;
			break;
		case 3:
			$newFilePath = '../../../../data/users/pictures/thumbnail3/';
			renameAndMoveToTrash($newFilePath . $fileName, $fileName);
			$width = $height = 80;
			break;
		default:
			break;
	}
	$newFilePath = $newFilePath . $fileName;
	
	$resizer = new ImageResize($filePath);
	$resizer -> resize($width, $height);
	$resizer -> save($newFilePath, null, 100);
}

$conn -> close();
?>
